
# Starting the application with default profile (MySql database)
`mvn clean spring-boot:run`

# Calling the API 
Start the application and connect to `http://localhost:8080/users/1`