/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to control "buy data" businesses.
 */
package com.sta.unitel.controller;

import com.sta.unitel.inteface.buy_data.IBuyData;
import com.sta.unitel.inteface.buy_data.request.BuyDataDetailRequest;
import com.sta.unitel.inteface.buy_data.request.BuyDataListRequest;
import com.sta.unitel.inteface.buy_data.request.ConfirmBuyDataRequest;
import com.sta.unitel.inteface.transactions.ITransactions;

import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@RequestMapping("/api/v1/buy-data")
@CrossOrigin("*")
public class BuyDataController {
    private static final String U_MONEY = "U-Money";
    private final IBuyData iBuyData;
    private final ITransactions iTransactions;

    public BuyDataController(IBuyData iBuyData, ITransactions iTransactions) {
        this.iBuyData = iBuyData;
        this.iTransactions = iTransactions;
    }

    @GetMapping("/listPackages")
    public ResponseEntity<Object> getListDataPackages(@Validated BuyDataListRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Get list internet data packages","0","0" ));
        return new ResponseEntity<>(iBuyData.getListDataPackages(request), HttpStatus.OK);
    }

    @PostMapping("/packageDetail")
    public ResponseEntity<Object> getListWaterBillProviders(@RequestBody @Validated BuyDataDetailRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Get internet data package detail","0","0" ));
        return new ResponseEntity<>(iBuyData.getPackageDetail(request), HttpStatus.OK);
    }

    @PostMapping("/confirm")
    public ResponseEntity<Object> confirmBuyData(@RequestBody @Validated ConfirmBuyDataRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"Confirm buy-data transaction","0","0" ));
        return new ResponseEntity<>(iBuyData.confirmBuyData(request), HttpStatus.OK);
    }
}
