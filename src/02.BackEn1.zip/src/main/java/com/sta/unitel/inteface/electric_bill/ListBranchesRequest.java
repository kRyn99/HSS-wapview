package com.sta.unitel.inteface.electric_bill;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ListBranchesRequest {
    private String phoneNumber;
    private String roleId;
    private String token;
    private String lang;
}
