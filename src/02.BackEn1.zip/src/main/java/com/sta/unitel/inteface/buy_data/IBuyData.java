/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to define some abstract methods of "buy data" businesses.
 */
package com.sta.unitel.inteface.buy_data;

import com.sta.unitel.inteface.buy_data.dto.ConfirmBuyDataDto;
import com.sta.unitel.inteface.buy_data.request.BuyDataDetailRequest;
import com.sta.unitel.inteface.buy_data.request.BuyDataListRequest;
import com.sta.unitel.inteface.buy_data.request.ConfirmBuyDataRequest;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.commons.dto.NativeRes1;

public interface IBuyData {
    NativeRes getListDataPackages(BuyDataListRequest request);
    NativeRes getPackageDetail(BuyDataDetailRequest request);
    NativeRes1<ConfirmBuyDataDto> confirmBuyData(ConfirmBuyDataRequest request);
}
