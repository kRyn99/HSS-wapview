package com.sta.unitel.inteface.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class NativeRes1<T> {
    private Integer status;
    private String message;
    private T result;
}