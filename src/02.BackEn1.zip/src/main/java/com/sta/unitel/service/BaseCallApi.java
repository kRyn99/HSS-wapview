package com.sta.unitel.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sta.unitel.controller.CommonsController;
import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.utils.CommonUtil;
import org.apache.logging.log4j.LogManager;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class BaseCallApi {

    private static final org.apache.logging.log4j.Logger logger = LogManager.getLogger(BaseCallApi.class);

    private  CommonUtil commonUtil;

    public BaseCallApi(CommonUtil commonUtil) {
        this.commonUtil = commonUtil;
    }
    public String callSoap(String xmlInput, String wsURL) {
        URL url = null;
        URLConnection connection = null;
        HttpURLConnection httpConn = null;
        String responseString = null;
        String outputString="";
        OutputStream out = null;
        InputStreamReader isr = null;
        BufferedReader in = null;
        try
        {
            url = new URL(wsURL);
            connection = url.openConnection();
            httpConn = (HttpURLConnection) connection;
            byte[] buffer = new byte[xmlInput.length()];
            buffer = xmlInput.getBytes();
            String SOAPAction = "";
            // Set the appropriate HTTP parameters.
            httpConn.setRequestProperty("Content-Length", String
                    .valueOf(buffer.length));
            httpConn.setRequestProperty("Content-Type",
                    "text/xml; charset=utf-8");
            httpConn.setRequestProperty("SOAPAction", SOAPAction);
            httpConn.setRequestMethod("POST");
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            out = httpConn.getOutputStream();
            out.write(buffer);
            out.close();
            // Read the response and write it to standard out.
            isr = new InputStreamReader(httpConn.getInputStream());
            in = new BufferedReader(isr);
            while ((responseString = in.readLine()) != null)
            {
                outputString = outputString + responseString;
            }
//            Document document = commonUtil.parseXmlFile(outputString);
//            NodeList nodeLst = document.getElementsByTagName("jsonObject");
//            Gson gson = new GsonBuilder().setPrettyPrinting().create();
//
//            String jsonOutput = gson.toJson(nodeLst.item(0));
//            System.out.println(jsonOutput);
            return outputString;


//            Gson gson = new Gson();
//            Document document = commonUtil.parseXmlFile(outputString);
//            return document;
//            NodeList nodeLst = document.getElementsByTagName("ns2:sayhelloResponse");
//
//            String webServiceResponse = nodeLst.item(0).getTextContent();
//            System.out.println(webServiceResponse);
//            return webServiceResponse;
        }
        catch (Exception e)
        {
            logger.error(e.getMessage());
            return null;
        }
    }
}
