package com.sta.unitel.inteface.electric_bill;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ListRecentElectricDto {
    private String processCode;
    private String partnerCode;
    private String entityCode;
    private String entityPhone;
    private String entityName;
    private Long amount;
}
