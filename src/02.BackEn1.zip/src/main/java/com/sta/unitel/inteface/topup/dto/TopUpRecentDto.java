/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "get list top-up recent" API.
 */
package com.sta.unitel.inteface.topup.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TopUpRecentDto {
    private String processCode;
    private String partnerCode;
    private String serviceCode;
    private String entityCode;
    private Long amount;
    private String icon;
}
