/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "get list of data packages" API.
 */
package com.sta.unitel.inteface.buy_data.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class BuyDataListDto {
    private boolean multPlan;
    private boolean registerAble;
    private String name;
    private String code;
    private String shortDes;
    private String iconUrl;
    private boolean isMultPlan;
    private boolean isRegisterAble;
    private Double state;
    private String serviceGroupOrder;
    private Double serviceOrder;
    private String imgDesUrl;
    private String serviceGroupType;
    private String vasType;
    private String vasTypeName;
    private String serviceType;
    private String subName;
    private String subCode;
    private String subShortDes;
    private String subPrice;
    private String unit;
    private String payType;
    private boolean ewRegisterable;
    private String typePackage;
}
