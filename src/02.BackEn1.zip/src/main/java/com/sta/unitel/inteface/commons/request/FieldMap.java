package com.sta.unitel.inteface.commons.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FieldMap {
    private Integer fieldID;
    private String value;

}
