package com.sta.unitel.inteface.sokxay;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ListRecentSokxayRequest {
    private String phoneNumber;
    private String token;
    private String fromDate;
    private String period;
    private String toDate;
    private String lang;
}
