/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to implement the methods that defined in ITransferToNonUMoney interface.
 */
package com.sta.unitel.service;

import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.transfer_to_non_umoney.ITransferToNonUMoney;
import com.sta.unitel.inteface.transfer_to_non_umoney.request.CheckNonUMoneyRequest;
import com.sta.unitel.inteface.transfer_to_non_umoney.request.ConfirmTransferToNonUMoneyRequest;
import com.sta.unitel.utils.RsaUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class TransferToNonUMoneyService implements ITransferToNonUMoney
{

    @Value("${prefix-url-service}")
    private String prefix_service_url;
    private ICommons iCommons;

    public TransferToNonUMoneyService(ICommons iCommons)
    {
        this.iCommons = iCommons;
    }
    @Override
    public NativeRes checkInfo(CheckNonUMoneyRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/policy/v2.0/transfer-nonumoney/check";
        HttpHeaders headersCheck = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersCheck.set("Accept-Language", request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersCheck);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes confirmTrans(ConfirmTransferToNonUMoneyRequest request)
    {
        final String uri = prefix_service_url + "mobileservice/api/customer/v2.0/transfer-nonumoney/confirm";
        HttpHeaders headersConfirm = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersConfirm.set("Accept-Language", request.getLang());
        headersConfirm.set("checkSum", "u-money");
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersConfirm);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }
}
