/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "view transaction detail" API.
 */
package com.sta.unitel.inteface.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionDetailDto {
    private String actionId;
    private String transactionId;
    private String processCode;
    private String transactionName;
    private String senderName;
    private String senderPhone;
    private String receiverPhone;
    private Long amount;
    private Long totalAmount;
    private Long fee;
    private Long discount;
    private Long commission;
    private String dateTime;
}
