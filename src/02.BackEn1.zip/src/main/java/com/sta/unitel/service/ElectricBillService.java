package com.sta.unitel.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sta.unitel.inteface.buy_data.dto.ConfirmBuyDataDto;
import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.commons.dto.NativeRes1;
import com.sta.unitel.inteface.electric_bill.*;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;
import com.sta.unitel.utils.RsaUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class ElectricBillService implements IElectric {
    @Value("${prefix-url-service}")
    private String prefix_service_url;

    private final ObjectMapper mapper;
    private ICommons iCommons;

    public ElectricBillService(ObjectMapper mapper, ICommons iCommons) {
        this.mapper = mapper;
        this.iCommons = iCommons;
    }
    @Override
    public NativeRes getListBranches(ListBranchesRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/partner/v2.0/electricity/branches" +
                "?phoneNumber=%s&roleId=%s&token=%s";
        String url = String.format(uri, request.getPhoneNumber(), request.getRoleId(), request.getToken());
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        if (request.getToken() == null || request.getToken().equals("")) {
//            Gson g = new Gson();
//            try {
//                ClassLoader classLoader = getClass().getClassLoader();
//                String fileName = "public/list_electric_branches.json";
//                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
//                String content = new String(Files.readAllBytes(file.toPath()));
//                return g.fromJson(content, NativeRes.class);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
            List<ListElectricBranchesDto> branchesDtoList = new ArrayList<>();
            branchesDtoList.add(new ListElectricBranchesDto("1", "NAKONLUANG"));
            branchesDtoList.add(new ListElectricBranchesDto("2", "Vientiane Province"));
            branchesDtoList.add(new ListElectricBranchesDto("3", "Luangnumtha Province"));
            branchesDtoList.add(new ListElectricBranchesDto("4", "Borkeo Province"));
            branchesDtoList.add(new ListElectricBranchesDto("5", "Oudomxay Province"));
            branchesDtoList.add(new ListElectricBranchesDto("6", "Luangprabang Province"));
            branchesDtoList.add(new ListElectricBranchesDto("7", "Xayabuly Province"));
            branchesDtoList.add(new ListElectricBranchesDto("8", "Huaphanh Province"));
            branchesDtoList.add(new ListElectricBranchesDto("9", "Xiengkhuang Province"));
            branchesDtoList.add(new ListElectricBranchesDto("10", "Phongsaly Province"));
            branchesDtoList.add(new ListElectricBranchesDto("11", "Borlikhamxay Province"));
            branchesDtoList.add(new ListElectricBranchesDto("13", "Khammouane Province"));
            branchesDtoList.add(new ListElectricBranchesDto("14", "Savannakhet Province"));
            branchesDtoList.add(new ListElectricBranchesDto("15", "Champasack Province"));
            branchesDtoList.add(new ListElectricBranchesDto("16", "Saravanh Province"));
            branchesDtoList.add(new ListElectricBranchesDto("17", "Sekong Province"));
            branchesDtoList.add(new ListElectricBranchesDto("18", "Attapeu Province"));
            return new NativeRes(200, "Get list bank successful", branchesDtoList);
        }
        httpHeaders.set("Accept-Language", request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

//    @Override
//    public NativeRes checkInfoElectric(CheckInfoElectricRequest request) {
//        final String uri = prefix_service_url + "mobileservice/api/partner/v2.0/account/info";
//        HttpHeaders httpHeaders = new HttpHeaders();
//        if (request.getLang() == null) {
//            request.setLang("en");
//        }
//        httpHeaders.set("Accept-Language", request.getLang());
//        request.setPartnerCode("PAYMENT_ELEC_EDL");
//        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
//        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
//    }

    @Override
    public NativeRes1<CheckInfoElectricDto> checkInfoElectric(CheckInfoElectricRequest request) {
        return new NativeRes1<>(200, "", new CheckInfoElectricDto("00000", "", "0.0",
                "4:10 06/01/2021", false, "ThinhNN1"));
    }

//    @Override
//    public NativeRes checkPolicyElectric(CheckPolicyElectricRequest request) {
//        final String uriPolicy = prefix_service_url + "mobileservice/api/partner/v2.0/account/info";
//        HttpHeaders httpHeaders = new HttpHeaders();
//        if (request.getLang() == null) {
//            request.setLang("en");
//        }
//        httpHeaders.set("Accept-Language", request.getLang());
//        request.setPartnerCode("PAYMENT_ELEC_EDL");
//        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
//        return iCommons.getApiBase(HttpMethod.POST, uriPolicy, httpEntity);
//    }

    @Override
    public NativeRes1<CheckElectricPolicyDto> checkPolicyElectric(CheckPolicyElectricRequest request) {
        return new NativeRes1<>(200, "", new CheckElectricPolicyDto("00002",
                "", "0.0", "4:10 06/01/2021",
                false, "DoanPV5", "10", "20", "30"));
    }

//    @Override
//    public NativeRes listRecentElectric(WaterBillRecentRequest request, String limit,
//                                        String offset, String phoneNumber, String roleId, String token) {
//        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/" +
//                "trans-recent?limit=%s&offset=%s&phoneNumber=%s&roleId=%s&token=%s";
//        String url = String.format(uri, limit, offset, phoneNumber, roleId, token);
//        HttpHeaders headersRecentElectric = new HttpHeaders();
//        if (request.getLang() == null) {
//            request.setLang("en");
//        }
//        headersRecentElectric.set("Accept-Language", request.getLang());
//        request.setPartnerCode("PAYMENT_ELEC_EDL");
//        request.setProcessCode("600102");
//        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersRecentElectric);
//        return iCommons.getApiBase(HttpMethod.PUT, url, httpEntity);
//    }
    @Override
    public NativeRes1<List<ListRecentElectricDto>> listRecentElectric(WaterBillRecentRequest request, String limit,
                                        String offset, String phoneNumber, String roleId, String token) {
        List<ListRecentElectricDto> listRecentElectricDto = new ArrayList<>();
        listRecentElectricDto.add(new ListRecentElectricDto("600102", "PAYMENT_ELEC_EDL1",
                "1", "1200", "AA", 11L));
        listRecentElectricDto.add(new ListRecentElectricDto("600103", "PAYMENT_ELEC_EDL2",
                "1", "2400", "BB", 100L));
        listRecentElectricDto.add(new ListRecentElectricDto("600104", "PAYMENT_ELEC_EDL3",
                "1", "3600", "CC", 200L));
        return new NativeRes1<>(200, "Transaction successfully", listRecentElectricDto);
    }

//    @Override
//    public NativeRes confirmElectricTrans(ConfirmElectricTransRequest request) {
//        final String uri = prefix_service_url + "mobileservice/api/partner/v2.0/payment/confirm";
//        HttpHeaders headersRecentElectric = new HttpHeaders();
//        if (request.getLang() == null) {
//            request.setLang("en");
//        }
//        headersRecentElectric.set("Accept-Language", request.getLang());
//        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
//        request.setPin(RsaUtil.getEncrypted(request.getPin()));
//        request.setPartnerCode("PAYMENT_ELEC_EDL");
//        HttpEntity<Object> httpEntity = new HttpEntity<>(request);
//        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
//    }

    @Override
    public NativeRes1<ConfirmBuyDataDto> confirmElectricTrans(ConfirmElectricTransRequest request) {
        if (request.getOtp().equals("666666")) {
            return new NativeRes1<>(200, "Transaction successfully", new ConfirmBuyDataDto("00001",
                    "Transaction successfully.",
                    "210106000170760",
                    "15:28 06/01/2021",
                    false));
        } else {
            return new NativeRes1<>(403, "The OTP is invalid", new ConfirmBuyDataDto("10003",
                    "The OTP is invalid.",
                    "210302000188760",
                    "13:38 02/03/2021",
                    false));
        }
    }
}
