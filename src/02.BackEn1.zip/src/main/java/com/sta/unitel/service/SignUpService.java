package com.sta.unitel.service;

import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.sign_up.*;
import com.sta.unitel.utils.RsaUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class SignUpService implements ISignUp {
    @Value("${prefix-url-service}")
    private String prefix_service_url;
    private static final String ACCEPT_LANG = "Accept-Language";

    private ICommons iCommons;

    public SignUpService(ICommons iCommons) {
        this.iCommons = iCommons;
    }

    @Override
    public NativeRes getOtpSignUp(OtpSignUpRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/unauth/otp";
        request.setPhoneNumber(RsaUtil.getEncrypted(request.getPhoneNumber()));
        HttpHeaders headersOtpSignUp = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersOtpSignUp.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersOtpSignUp);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes checkSignUpCondition(CheckSignUpConditionRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/register/check" +
                "?phoneNumber=%s&roleId=%s";
        HttpHeaders headersCheckSignUp = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersCheckSignUp.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersCheckSignUp);
        String url = String.format(uri, request.getPhoneNumber(), request.getRoleId());
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes confirmSignUp(ConfirmSignUpRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/customer/v2.0/register/confirm";
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        httpHeaders.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes activeSignUp(ActiveSignUpRequest request) {
        final String uri = prefix_service_url +"mobileservice/api/common/v2.0/active";
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        httpHeaders.set(ACCEPT_LANG, request.getLang());
        httpHeaders.set("deviceId", "1");
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }
}
