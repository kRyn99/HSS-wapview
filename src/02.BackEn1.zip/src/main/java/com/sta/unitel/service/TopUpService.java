/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to implement the methods that defined in ITopUp interface.
 */
package com.sta.unitel.service;

import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.topup.ITopUp;
import com.sta.unitel.inteface.topup.request.CheckInfoTopUpRequest;
import com.sta.unitel.inteface.topup.request.ConfirmTransactionTopUpRequest;
import com.sta.unitel.inteface.topup.request.TopUpRecentRequest;
import com.sta.unitel.utils.RsaUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class TopUpService implements ITopUp {
    @Value("${prefix-url-service}")
    private String prefix_service_url;
    private static final String ACCEPT_LANG = "Accept-Language";

    private ICommons iCommons;

    public TopUpService(ICommons iCommons)
    {
        this.iCommons = iCommons;
    }
    @Override
    public NativeRes checkInfoTopUp(CheckInfoTopUpRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/policy/v2.0/topup/check";
        HttpHeaders headersCheckTopUp = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersCheckTopUp.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersCheckTopUp);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes confirmTransactionTopUp(ConfirmTransactionTopUpRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/customer/v2.0/topup/confirm";
        HttpHeaders httpHeadersConfirmTopUp = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        httpHeadersConfirmTopUp.set(ACCEPT_LANG, request.getLang());
        httpHeadersConfirmTopUp.set("checkSum", "u-money");
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeadersConfirmTopUp);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes getListTopUpRecent(TopUpRecentRequest request, String limit, String offset,
                                        String phoneNumber, String roleId, String token) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/topup/" +
                "trans-recent?limit=%s&offset=%s&phoneNumber=%s&roleId=%s&token=%s";
        HttpHeaders headersRecentTopUp = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersRecentTopUp.set(ACCEPT_LANG, request.getLang());
        String url = String.format(uri, limit, offset, phoneNumber, roleId, token);
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersRecentTopUp);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }
}
