package com.sta.unitel.inteface.commons.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CheckAccountEWalletRequest {
    private String phoneNumber;
    private String roleId;
    private String lang;
    private String deviceId;
}
