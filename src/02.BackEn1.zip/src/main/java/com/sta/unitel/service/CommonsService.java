/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to implement the methods that defined in ICommons1 interface.
 */
package com.sta.unitel.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.commons.request.CheckAccountEWalletRequest;
import com.sta.unitel.inteface.commons.request.OtpRequest;
import com.sta.unitel.inteface.commons.request.TransactionDetailRequest;
import com.sta.unitel.inteface.commons.request.TransactionRecentRequest;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;
import com.sta.unitel.utils.RsaUtil;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

@Service

public class CommonsService implements ICommons {

    @Value("${prefix-url-service}")
    private String prefix_service_url;

    private static final String ACCEPT_LANG = "Accept-Language";
    private static final String COMMON_URL = "mobileservice/api/common/v2.0/";
    private static final String COMMON_URL_PARAMS = "trans-recent?limit=%s&offset=%s&phoneNumber=%s&roleId=%s&token=%s";
    private static final String COMMON_URL_PARAMS_COMMON = "trans-history?limit=%s&offset=%s&phoneNumber=%s&roleId=%s&token=%s";

    private final ObjectMapper mapper;

    public CommonsService(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public NativeRes getOtp(OtpRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/auth/otp";
        HttpHeaders headers = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headers.set(ACCEPT_LANG, request.getLang());
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headers);
        return this.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes checkAccountEWallet(CheckAccountEWalletRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/account/check?phoneNumber=%s&roleId=%s";
        HttpHeaders header = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        header.set(ACCEPT_LANG, request.getLang());
        header.set("addition", "1");
        header.set("deviceId", request.getDeviceId());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, header);
        String url = String.format(uri, request.getPhoneNumber(), request.getRoleId());
        return this.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes getListTransactionRecent(TransactionRecentRequest request, String limit,
                                              String offset, String phoneNumber, String roleId, String token) {
        final String uri = prefix_service_url + COMMON_URL +
                COMMON_URL_PARAMS_COMMON;
        HttpHeaders headersRecent = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersRecent.set(ACCEPT_LANG, request.getLang());
        String url = String.format(uri, limit, offset, phoneNumber, roleId, token);
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersRecent);
        return this.getApiBase(HttpMethod.PUT, url, httpEntity);
    }

    @Override
    public NativeRes getTransDetail(TransactionDetailRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/trans-history/" +
                "details?actionId=%s&phoneNumber=%s&roleId=%s&token=%s";
        String url = String.format(uri, request.getActionId(),
                request.getPhoneNumber(), request.getRoleId(), request.getToken());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request);
        return this.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes getListRecentBank(WaterBillRecentRequest requestBank, String limit, String offset,
                                       String phoneNumber, String roleId, String token) {
        final String uriBank = prefix_service_url + COMMON_URL +
                COMMON_URL_PARAMS;
        HttpHeaders headersRecentBank = new HttpHeaders();
        if (requestBank.getLang() == null) {
            requestBank.setLang("en");
        }
        headersRecentBank.set(ACCEPT_LANG, requestBank.getLang());
        String url = String.format(uriBank, limit, offset, phoneNumber, roleId, token);
        requestBank.setProcessCode("600011");
        HttpEntity<Object> httpEntity = new HttpEntity<>(requestBank, headersRecentBank);
        return this.getApiBase(HttpMethod.PUT, url, httpEntity);
    }

    @Override
    public NativeRes getListRecentUMoney(WaterBillRecentRequest requestUMoney, String limit, String offset,
                                         String phoneNumber, String roleId, String token) {
        final String uriUMoney = prefix_service_url + COMMON_URL +
                COMMON_URL_PARAMS;
        HttpHeaders headersRecentUMoney = new HttpHeaders();
        if (requestUMoney.getLang() == null) {
            requestUMoney.setLang("en");
        }
        headersRecentUMoney.set(ACCEPT_LANG, requestUMoney.getLang());
        String url = String.format(uriUMoney, limit, offset, phoneNumber, roleId, token);
        requestUMoney.setPartnerCode(null);
        requestUMoney.setProcessCode("021000");
        HttpEntity<Object> httpEntity = new HttpEntity<>(requestUMoney, headersRecentUMoney);
        return this.getApiBase(HttpMethod.PUT, url, httpEntity);
    }

    @Override
    public NativeRes getListRecentNonUMoney(WaterBillRecentRequest requestNonU, String limit, String offset,
                                            String phoneNumber, String roleId, String token) {
        final String uriNon = prefix_service_url + COMMON_URL +
                COMMON_URL_PARAMS;
        HttpHeaders headersRecentNonU = new HttpHeaders();
        if (requestNonU.getLang() == null) {
            requestNonU.setLang("en");
        }
        headersRecentNonU.set(ACCEPT_LANG, requestNonU.getLang());
        String url = String.format(uriNon, limit, offset, phoneNumber, roleId, token);
        requestNonU.setPartnerCode(null);
        requestNonU.setProcessCode("021001");
        HttpEntity<Object> httpEntity = new HttpEntity<>(requestNonU, headersRecentNonU);
        return this.getApiBase(HttpMethod.PUT, url, httpEntity);
    }

    @Override
    public NativeRes getApiBase(HttpMethod method, String url, HttpEntity<Object> httpEntity) {
        CloseableHttpClient httpClient = HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier()).build();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);
        RestTemplate restTemplate = new RestTemplate(requestFactory);
        String error;
        try {
            if (method == HttpMethod.GET) {
                return restTemplate.exchange(url, HttpMethod.GET, httpEntity, NativeRes.class).getBody();
            } else if (method == HttpMethod.POST) {
                return restTemplate.exchange(url, HttpMethod.POST, httpEntity, NativeRes.class).getBody();
            } else if (method == HttpMethod.PUT) {
                return restTemplate.exchange(url, HttpMethod.PUT, httpEntity, NativeRes.class).getBody();
            } else {
                return null;
            }
        } catch (HttpStatusCodeException ex) {
            error = ex.getResponseBodyAsString();
            try {
                return mapper.readValue(error, NativeRes.class);
            } catch (JsonProcessingException e) {
                throw new IllegalArgumentException(e);
            }
        }
    }

}
