/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define the fields of request for "view list of transactions recently" API.
 */
package com.sta.unitel.inteface.commons.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TransactionRecentRequest {
    private String fromDate;
    private String[] ofTrans;
    private String toDate;
    private String limit;
    private String offset;
    private String phoneNumber;
    private String roleId;
    private String token;
    private String lang;
}
