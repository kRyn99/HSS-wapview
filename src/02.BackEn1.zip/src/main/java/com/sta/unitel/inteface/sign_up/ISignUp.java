package com.sta.unitel.inteface.sign_up;

import com.sta.unitel.inteface.commons.dto.NativeRes;

public interface ISignUp {
    NativeRes getOtpSignUp(OtpSignUpRequest request);
    NativeRes checkSignUpCondition(CheckSignUpConditionRequest request);
    NativeRes confirmSignUp(ConfirmSignUpRequest request);
    NativeRes activeSignUp(ActiveSignUpRequest request);
}
