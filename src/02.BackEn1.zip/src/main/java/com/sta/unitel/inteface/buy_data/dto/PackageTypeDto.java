package com.sta.unitel.inteface.buy_data.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PackageTypeDto {
    private List<BuyDataListDto> casualType;
    private List<BuyDataListDto> specialType;
}
