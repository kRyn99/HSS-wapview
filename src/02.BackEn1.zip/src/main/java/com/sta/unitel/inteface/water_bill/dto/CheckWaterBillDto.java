/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "retrieve water bill customer info" API.
 */
package com.sta.unitel.inteface.water_bill.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CheckWaterBillDto {
    private String responseCode;
    private String responseDescription;
    private String amount;
    private String balance;
    private String transactionDateTime;
    private boolean requireOtp;
    private String accountName;
}
