/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define a model in order to create a corresponding table in database .
 */
package com.sta.unitel.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GenerationType;
import javax.persistence.Column;

@Data @Entity
@Table(name = "transaction")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 50)
    private String appMe;
    private String requestInfo;
    private String user;
    private String urlApi;

    public Transaction(String appMe, String requestInfo, String user, String urlApi) {
        this.appMe = appMe;
        this.requestInfo = requestInfo;
        this.user = user;
        this.urlApi = urlApi;
    }

    public Transaction() {
    }


}
