/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to control some common businesses.
 */
package com.sta.unitel.controller;

import com.google.gson.Gson;
import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.*;
import com.sta.unitel.inteface.commons.request.CheckAccountEWalletRequest;
import com.sta.unitel.inteface.commons.request.OtpRequest;
import com.sta.unitel.inteface.commons.request.TransactionDetailRequest;
import com.sta.unitel.inteface.commons.request.TransactionRecentRequest;
import com.sta.unitel.inteface.my_id.CheckMochaPhoneRequest;
import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;
import com.sta.unitel.model.Transaction;
import com.sta.unitel.service.BaseCallApi;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/api/v1/commons")
@CrossOrigin("*")
public class CommonsController {

    private static final Logger logger = LogManager.getLogger(CommonsController.class);

    private static final String U_MONEY = "U-Money";
    private final ICommons iCommons;

    private final ITransactions iTransactions;
    private BaseCallApi baseCallApi;
    private MessageSource messageSource;

    @Value("${prefix-url-service-myid}")
    private String prefix_service_url_myid;

    public CommonsController(ICommons iCommons,
                             ITransactions iTransactions, BaseCallApi baseCallApi, MessageSource messageSource) {
        this.iCommons = iCommons;
        this.iTransactions = iTransactions;
        this.baseCallApi = baseCallApi;
        this.messageSource = messageSource;
    }

    @PostMapping("/transaction-detail")
    public ResponseEntity<Object> transactionDetail(@RequestBody @Validated TransactionDetailRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "View transaction detail", "0", "0"));
        return new ResponseEntity<>(iCommons.getTransDetail(request), HttpStatus.OK);
    }


    @PostMapping("/transaction-recent")
    public ResponseEntity<Object> transactionRecent(@RequestBody @Validated TransactionRecentRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "View list of transactions recently", "0", "0"));
        return new ResponseEntity<>(iCommons.getListTransactionRecent(request, request.getLimit(), request.getOffset(),
                request.getPhoneNumber(), request.getRoleId(), request.getToken()), HttpStatus.OK);
    }

    @PostMapping("/get-otp")
    public ResponseEntity<Object> checkOtp(@RequestBody @Validated OtpRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "Get OTP", "0", "0"));
        return new ResponseEntity<>(iCommons.getOtp(request), HttpStatus.OK);
    }

    @PostMapping("/check-account-ewallet")
    public ResponseEntity<Object> checkAccountEWallet(@RequestBody @Validated CheckAccountEWalletRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "Check E-wallet account", "0", "0"));
        return new ResponseEntity<>(iCommons.checkAccountEWallet(request), HttpStatus.OK);
    }

    @PostMapping("/transaction-recent/bank")
    public ResponseEntity<Object> transactionRecentBank(@RequestBody WaterBillRecentRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "View list of transactions recent | bank", "0", "0"));
        return new ResponseEntity<>(iCommons.getListRecentBank(request, request.getLimit(), request.getOffset(),
                request.getPhoneNumber(), request.getRoleId(), request.getToken()), HttpStatus.OK);
    }

    @PostMapping("/transaction-recent/u-money")
    public ResponseEntity<Object> transactionRecentUMoney(@RequestBody WaterBillRecentRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "View list of transactions recent | u-money", "0", "0"));
        return new ResponseEntity<>(iCommons.getListRecentUMoney(request, request.getLimit(), request.getOffset(),
                request.getPhoneNumber(), request.getRoleId(), request.getToken()), HttpStatus.OK);
    }

    @PostMapping("/transaction-recent/non-u-money")
    public ResponseEntity<Object> transactionRecentNonUMoney(@RequestBody WaterBillRecentRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "View list of transactions recent | non u-money", "0", "0"));
        return new ResponseEntity<>(iCommons.getListRecentNonUMoney(request, request.getLimit(), request.getOffset(),
                request.getPhoneNumber(), request.getRoleId(), request.getToken()), HttpStatus.OK);
    }
    @PostMapping("/mocha/info-by-phone")
    public ResponseEntity<Object> infoByPhone(@RequestBody CheckMochaPhoneRequest request) {
        try {
            Locale  locale = new Locale.Builder().setLanguage(request.getLang()).build();
            List<FieldMapRequet> fieldMapRequets = new ArrayList<>();
            fieldMapRequets.add(new FieldMapRequet(0,"0200"));
            fieldMapRequets.add(new FieldMapRequet(3,"311202"));
            fieldMapRequets.add(new FieldMapRequet(22,"7"));
            fieldMapRequets.add(new FieldMapRequet(34,"8562093657317"));
            fieldMapRequets.add(new FieldMapRequet(41,"BCCS"));
            fieldMapRequets.add(new FieldMapRequet(42,"CHECK_INFO_CANCEL"));
//            String xmlInput =
//                    "{" +
//                            " \"fieldMap\": [" +
//                            " {" +
//                            " \"fieldID\": 0," +
//                            " \"value\": \"0200\"" +
//                            " }," +
//                            " {" +
//                            " \"fieldID\": 3," +
//                            " \"value\": \"311202\"" +
//                            " }," +
//                            " {" +
//                            " \"fieldID\": 22," +
//                            " \"value\": 7" +
//                            " }," +
//                            " {" +
//                            " \"fieldID\": 34," +
//                            " \"value\": \"8562093657317\"" +
//                            " }," +
//                            " {" +
//                            " \"fieldID\": 41," +
//                            " \"value\": \"BCCS\"" +
//                            " }," +
//                            " {" +
//                            " \"fieldID\": 42," +
//                            " \"value\": \"CHECK_INFO_CANCEL\"" +
//                            " }" +
//                            " ]" +
//                            "}";
            HttpHeaders headers = new HttpHeaders();
            FieldMapFormRequet fieldMapFormRequet = new FieldMapFormRequet();
            fieldMapFormRequet.setFieldMap(fieldMapRequets);
            HttpEntity<Object> httpEntity = new HttpEntity<>(fieldMapFormRequet, headers);
            NativeRes nativeRes = iCommons.getApiBase(HttpMethod.POST, prefix_service_url_myid + "sendRequest", httpEntity);
        //    String documentResponse = baseCallApi.callSoap(xmlInput, prefix_service_url_myid + "sendRequest");
//            logger.error(documentResponse);
//            JSONObject json = XML.toJSONObject(documentResponse);
//            Gson gson = new Gson();
//            JSONObject json2 = json.getJSONObject("S:Envelope");
//            JSONObject json3 = json2.getJSONObject("S:Body");
//            CheckPhoneDto checkPhoneDto = gson.fromJson(json3.getJSONObject("jsonObject").toString(),
//                    CheckPhoneDto.class);
//            switch (checkPhoneDto.getResponseCode()) {
//                case "00000":
//                    checkPhoneDto.setStatus(200);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("success_check", null, locale));
//                    break;
//                case "99999":
//                    checkPhoneDto.setStatus(999);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("error_core_exception", null, locale));
//                    break;
//                case "99998":
//                    checkPhoneDto.setStatus(998);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("error_authenticate", null, locale));
//                    break;
//                case "10130":
//                    checkPhoneDto.setStatus(130);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("error_miss_field_request", null, locale));
//                    break;
//                case "10532":
//                    checkPhoneDto.setStatus(532);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("error_timeout", null, locale));
//                    break;
//                case "10112":
//                    checkPhoneDto.setStatus(112);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("error_encrypt_signature", null, locale));
//                    break;
//                case "10113":
//                    checkPhoneDto.setStatus(113);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("error_duplicate", null, locale));
//                    break;
//                case "10114":
//                    checkPhoneDto.setStatus(114);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("invalid_pin", null, locale));
//                    break;
//                case "10115":
//                    checkPhoneDto.setStatus(115);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("invalid_secret", null, locale));
//                    break;
//                case "10116":
//                    checkPhoneDto.setStatus(116);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("not_registered", null, locale));
//                    break;
//                case "10117":
//                    checkPhoneDto.setStatus(117);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("account_canceled", null, locale));
//                    break;
//                case "10118":
//                    checkPhoneDto.setStatus(118);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("account_blocked", null, locale));
//                    break;
//                case "10122":
//                    checkPhoneDto.setStatus(122);
//                    checkPhoneDto.setMessage_account(
//                            messageSource.getMessage("not_activated", null, locale));
//                    break;
//            }

            return new ResponseEntity<>(nativeRes, HttpStatus.OK);
        } catch (Exception ex){
            logger.error(ex.getMessage());
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/mocha/checkPhonenumber")
    public ResponseEntity<Object> checkMochaUmoney(@RequestBody CheckMochaPhoneRequest request) {
        try {
            Locale  locale = new Locale.Builder().setLanguage(request.getLang()).build();
            String xmlInput =
                    "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:" +
                            "web=\"http://webservice.coreapp.ewallet.viettel.com/\">\n" +
                            "   <soapenv:Header/>\n" +
                            "   <soapenv:Body>\n" +
                            "      <web:getInfo>\n" +
                            "         <!--Optional:-->\n" +
                            "         <input>\n" +
                            "         \t   <fieldMap>\n" +
                            "               <fieldID>0</fieldID>\n" +
                            "               <value>0200</value>\n" +
                            "            </fieldMap>\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>3</fieldID>\n" +
                            "               <value>311202</value>\n" +
                            "            </fieldMap>\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>22</fieldID>\n" +
                            "               <value>7</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--Phone:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>34</fieldID>\n" +
                            "               <value>" + request.getPhoneNumber() + "</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--PartnerCode:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>41</fieldID>\n" +
                            "               <value>BCCS</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--SERVICE_CODE:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>42</fieldID>\n" +
                            "               <value>CHECK_INFO_CANCEL</value>\n" +
                            "            </fieldMap>\n" +
                            "             <fieldMap>\n" +
                            "               <fieldID>64</fieldID>\n" +
                            "               <value>24fa5fbda7748e690cc633b4ec563f62</value>\n" +
                            "            </fieldMap>\n" +
                            "         </input>\n" +
                            "      </web:getInfo>\n" +
                            "   </soapenv:Body>\n" +
                            "</soapenv:Envelope>";
            String documentResponse = baseCallApi.callSoap(xmlInput, prefix_service_url_myid + "sendRequest");
            logger.error(documentResponse);
            JSONObject json = XML.toJSONObject(documentResponse);
            Gson gson = new Gson();
            JSONObject json2 = json.getJSONObject("S:Envelope");
            JSONObject json3 = json2.getJSONObject("S:Body");
            CheckPhoneDto checkPhoneDto = gson.fromJson(json3.getJSONObject("jsonObject").toString(),
                    CheckPhoneDto.class);
            switch (checkPhoneDto.getResponseCode()) {
                case "00000":
                    checkPhoneDto.setStatus(200);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("success_check", null, locale));
                    break;
                case "99999":
                    checkPhoneDto.setStatus(999);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("error_core_exception", null, locale));
                    break;
                case "99998":
                    checkPhoneDto.setStatus(998);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("error_authenticate", null, locale));
                    break;
                case "10130":
                    checkPhoneDto.setStatus(130);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("error_miss_field_request", null, locale));
                    break;
                case "10532":
                    checkPhoneDto.setStatus(532);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("error_timeout", null, locale));
                    break;
                case "10112":
                    checkPhoneDto.setStatus(112);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("error_encrypt_signature", null, locale));
                    break;
                case "10113":
                    checkPhoneDto.setStatus(113);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("error_duplicate", null, locale));
                    break;
                case "10114":
                    checkPhoneDto.setStatus(114);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("invalid_pin", null, locale));
                    break;
                case "10115":
                    checkPhoneDto.setStatus(115);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("invalid_secret", null, locale));
                    break;
                case "10116":
                    checkPhoneDto.setStatus(116);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("not_registered", null, locale));
                    break;
                case "10117":
                    checkPhoneDto.setStatus(117);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("account_canceled", null, locale));
                    break;
                case "10118":
                    checkPhoneDto.setStatus(118);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("account_blocked", null, locale));
                    break;
                case "10122":
                    checkPhoneDto.setStatus(122);
                    checkPhoneDto.setMessage_account(
                            messageSource.getMessage("not_activated", null, locale));
                    break;
            }

            return new ResponseEntity<>(checkPhoneDto, HttpStatus.OK);
        } catch (Exception ex){
            logger.error(ex.getMessage());
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/sendRequest")
    public ResponseEntity<Object> sendRequest(@RequestBody CheckMochaPhoneRequest request) {
        try {
            Locale  locale = new Locale.Builder().setLanguage(request.getLang()).build();
            String xmlInput =
                    "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:" +
                            "web=\"http://webservice.coreapp.ewallet.viettel.com/\">\n" +
                            "   <soapenv:Header/>\n" +
                            "   <soapenv:Body>\n" +
                            "      <web:getInfo>\n" +
                            "         <!--Optional:-->\n" +
                            "         <input>\n" +
                            "         \t   <fieldMap>\n" +
                            "               <fieldID>0</fieldID>\n" +
                            "               <value>0200</value>\n" +
                            "            </fieldMap>\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>3</fieldID>\n" +
                            "               <value>311202</value>\n" +
                            "            </fieldMap>\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>22</fieldID>\n" +
                            "               <value>7</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--Phone:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>34</fieldID>\n" +
                            "               <value>" + request.getPhoneNumber() + "</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--PartnerCode:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>41</fieldID>\n" +
                            "               <value>BCCS</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--SERVICE_CODE:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>42</fieldID>\n" +
                            "               <value>CHECK_INFO_CANCEL</value>\n" +
                            "            </fieldMap>\n" +
                            "             <fieldMap>\n" +
                            "               <fieldID>64</fieldID>\n" +
                            "               <value>24fa5fbda7748e690cc633b4ec563f62</value>\n" +
                            "            </fieldMap>\n" +
                            "         </input>\n" +
                            "      </web:getInfo>\n" +
                            "   </soapenv:Body>\n" +
                            "</soapenv:Envelope>";

            String documentResponse = baseCallApi.callSoap(xmlInput, prefix_service_url_myid + "sendRequest");
            JSONObject json = XML.toJSONObject(documentResponse);
            Gson gson = new Gson();
            JSONObject json2 = json.getJSONObject("S:Envelope");
            JSONObject json3 = json2.getJSONObject("S:Body");
            CheckPhoneDto checkPhoneDto = gson.fromJson(json3.getJSONObject("jsonObject").toString(),
                    CheckPhoneDto.class);
            String xmlInput2 =
                    "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:" +
                            "web=\"http://webservice.coreapp.ewallet.viettel.com/\">\n" +
                            "   <soapenv:Header/>\n" +
                            "   <soapenv:Body>\n" +
                            "      <web:getInfo>\n" +
                            "         <!--Optional:-->\n" +
                            "         <input>\n" +
                            "         \t   <fieldMap>\n" +
                            "               <fieldID>0</fieldID>\n" +
                            "               <value>0200</value>\n" +
                            "            </fieldMap>\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>3</fieldID>\n" +
                            "               <value>311202</value>\n" +
                            "            </fieldMap>\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>22</fieldID>\n" +
                            "               <value>7</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--Phone:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>34</fieldID>\n" +
                            "               <value>" + request.getToPhone() + "</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--PartnerCode:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>41</fieldID>\n" +
                            "               <value>BCCS</value>\n" +
                            "            </fieldMap>\n" +
                            "            <!--SERVICE_CODE:-->\n" +
                            "            <fieldMap>\n" +
                            "               <fieldID>42</fieldID>\n" +
                            "               <value>CHECK_INFO_CANCEL</value>\n" +
                            "            </fieldMap>\n" +
                            "             <fieldMap>\n" +
                            "               <fieldID>64</fieldID>\n" +
                            "               <value>24fa5fbda7748e690cc633b4ec563f62</value>\n" +
                            "            </fieldMap>\n" +
                            "         </input>\n" +
                            "      </web:getInfo>\n" +
                            "   </soapenv:Body>\n" +
                            "</soapenv:Envelope>";
            String documentResponse2 = baseCallApi.callSoap(xmlInput2, prefix_service_url_myid + "sendRequest");
            JSONObject json4 = XML.toJSONObject(documentResponse2);
            Gson gson2 = new Gson();
            JSONObject json5 = json4.getJSONObject("S:Envelope");
            JSONObject json6 = json5.getJSONObject("S:Body");
            CheckPhoneDto checkPhoneDto2 = gson2.fromJson(json6.getJSONObject("jsonObject").toString(),
                    CheckPhoneDto.class);
            CheckCommonResult checkCommonResult = new CheckCommonResult();
            checkCommonResult.setCheckPhoneDtoList(new ArrayList<>());
            checkCommonResult.getCheckPhoneDtoList().add(checkPhoneDto);
            checkCommonResult.getCheckPhoneDtoList().add(checkPhoneDto2);

            switch (checkCommonResult.getCheckPhoneDtoList().get(0).getResponseCode()) {
                case "00000":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("success_check", null, locale));
                    break;
                case "99999":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("error_core_exception", null, locale));
                    break;
                case "99998":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("error_authenticate", null, locale));
                    break;
                case "10130":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("error_miss_field_request", null, locale));
                    break;
                case "10532":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("error_timeout", null, locale));
                    break;
                case "10112":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("error_encrypt_signature", null, locale));
                    break;
                case "10113":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("error_duplicate", null, locale));
                    break;
                case "10114":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("invalid_pin", null, locale));
                    break;
                case "10115":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("invalid_secret", null, locale));
                    break;
                case "10116":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setStatus(116);
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("not_registered", null, locale));
                    break;
                case "10117":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("account_canceled", null, locale));
                    break;
                case "10118":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("account_blocked", null, locale));
                    break;
                case "10122":
                    checkCommonResult.getCheckPhoneDtoList().get(0).setMessage_account(
                            messageSource.getMessage("not_activated", null, locale));
                    break;
            }

            switch (checkCommonResult.getCheckPhoneDtoList().get(1).getResponseCode()) {
                case "00000":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("success_check", null, locale));
                    break;
                case "99999":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("error_core_exception", null, locale));
                    break;
                case "99998":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("error_authenticate", null, locale));
                    break;
                case "10130":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("error_miss_field_request", null, locale));
                    break;
                case "10532":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("error_timeout", null, locale));
                    break;
                case "10112":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("error_encrypt_signature", null, locale));
                    break;
                case "10113":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("error_duplicate", null, locale));
                    break;
                case "10114":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("invalid_pin", null, locale));
                    break;
                case "10115":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("invalid_secret", null, locale));
                    break;
                case "10116":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setStatus(116);
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("not_registered", null, locale));
                    break;
                case "10117":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("account_canceled", null, locale));
                    break;
                case "10118":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("account_blocked", null, locale));
                    break;
                case "10122":
                    checkCommonResult.getCheckPhoneDtoList().get(1).setMessage_account(
                            messageSource.getMessage("not_activated", null, locale));
                    break;
            }

            if (checkCommonResult.getCheckPhoneDtoList().get(0).getResponseCode().equals("00000") &&
                    checkCommonResult.getCheckPhoneDtoList().get(1).getResponseCode().equals("00000")) {
                checkCommonResult.setStatus(990);
            } else if (checkCommonResult.getCheckPhoneDtoList().get(0).getResponseCode().equals("00000") &&
                    !checkCommonResult.getCheckPhoneDtoList().get(1).getResponseCode().equals("00000")) {
                checkCommonResult.setStatus(991);
                checkCommonResult.setMessage(
                        messageSource.getMessage("receiver_no", null, locale));
            } else {
                checkCommonResult.setStatus(992);
                checkCommonResult.setMessage(
                        messageSource.getMessage("sender_no", null, locale));
            }
            return new ResponseEntity<>(checkCommonResult, HttpStatus.OK);
        } catch (Exception ex) {
            logger.error(ex.getMessage());
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }



//        try {
//            if (request.getAmount() <= 0L || request.getAmount() > 99999999L) {
//                checkCommonResult.setMessage_amount(messageSource.getMessage("amount_invalid", null, locale));
//            } else {
//                checkCommonResult.setAmount(request.getAmount());
//            }
//
//            if (isAccent(request.getContent())) {
//                checkCommonResult.setMessage_content(messageSource.getMessage("content_accent", null, locale));
//            } else if (request.getContent().trim().length() > 50) {
//                checkCommonResult.setMessage_content(messageSource.getMessage("content_length_invalid", null, locale));
//            } else {
//                checkCommonResult.setContent(request.getContent().trim());
//            }
//        } catch (Throwable ex) {
//            System.out.println("Message of Exception : " + ex.getMessage());
//        }


    }

    public boolean isAccent(String s) {
        String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return !pattern.matcher(temp).replaceAll("").replaceAll("Đ", "D").
                replace("đ", "d").equals(s);
    }
}
