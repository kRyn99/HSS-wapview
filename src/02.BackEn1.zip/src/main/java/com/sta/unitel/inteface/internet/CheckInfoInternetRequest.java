package com.sta.unitel.inteface.internet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CheckInfoInternetRequest {
    private String account;
    private Long amount;
    private String phoneNumber;
    private Integer type;
    private String lang;
}
