package com.sta.unitel.inteface.transfer_to_banks.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CheckOnlyBankAccountNoRequest {
    private String bankAccountNo;
    private String partnerCode;
    private String phoneNumber;
    private String lang;
}
