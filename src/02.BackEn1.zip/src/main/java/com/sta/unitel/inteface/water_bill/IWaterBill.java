/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to define some abstract methods of water bill businesses.
 */
package com.sta.unitel.inteface.water_bill;

import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.water_bill.request.CheckWaterBillRequest;
import com.sta.unitel.inteface.water_bill.request.ConfirmWaterBillRequest;
import com.sta.unitel.inteface.water_bill.request.WaterBillProvidersRequest;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;

public interface IWaterBill {
    NativeRes checkWaterBill(CheckWaterBillRequest request);
    NativeRes confirmWaterBill(ConfirmWaterBillRequest request);
    NativeRes getListWaterBillProviders(WaterBillProvidersRequest request);
    NativeRes getListWaterBillTransRecent(WaterBillRecentRequest request, String limit, String offset,
                                          String phoneNumber, String roleId, String token);
}
