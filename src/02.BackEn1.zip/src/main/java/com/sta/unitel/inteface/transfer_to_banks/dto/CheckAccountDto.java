/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "check account transfer to bank" API.
 */
package com.sta.unitel.inteface.transfer_to_banks.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CheckAccountDto {
    private String responseCode;
    private String responseDescription;
    private String transactionDateTime;
    private String bankAccountName;
    private boolean requireOtp;
}
