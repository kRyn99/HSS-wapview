/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to declare some abstract methods of transfer to bank businesses.
 */
package com.sta.unitel.inteface.transfer_to_banks;

import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.transfer_to_banks.request.CheckAccountRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.CheckOnlyBankAccountNoRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.ConfirmTransferToBanksRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.ListBankRequest;

public interface ITransferToBanks {
    NativeRes getApiListBank(ListBankRequest request);
    NativeRes checkAccount(CheckAccountRequest request);
    NativeRes confirmBank(ConfirmTransferToBanksRequest request);
    NativeRes checkOnlyBankAccountNo(CheckOnlyBankAccountNoRequest request);

}
