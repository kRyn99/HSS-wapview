package com.sta.unitel.inteface.sign_up;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ConfirmSignUpRequest {
    private String additionalData;
    private String dateOfBirth;
    private String fullName;
    private Integer gender;
    private String paperNumber;
    private Integer paperType;
    private String phoneNumber;
    private String lang;
}
