package com.sta.unitel.controller;

import com.sta.unitel.inteface.sokxay.CheckInfoSokxayRequest;
import com.sta.unitel.inteface.sokxay.ConfirmSokxayRequest;
import com.sta.unitel.inteface.sokxay.ISokxay;
import com.sta.unitel.inteface.sokxay.ListRecentSokxayRequest;
import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/sokxay")
@CrossOrigin("*")
public class SokxayController {
    private final String U_MONEY = "U-Money";
    private final ISokxay iSokxay;
    private final ITransactions iTransactions;


    public SokxayController(ISokxay iSokxay, ITransactions iTransactions) {
        this.iSokxay = iSokxay;
        this.iTransactions = iTransactions;
    }

    @PostMapping("/check-policy")
    public ResponseEntity<Object> checkPolicySokxay(@RequestBody @Validated CheckInfoSokxayRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "check policy Sokxay", "0", "0"));
        return new ResponseEntity<>(iSokxay.checkInfoSokxay(request), HttpStatus.OK);
    }
    @PostMapping("/list-recent-sokxay")
    public ResponseEntity<Object> listRecentSokxay(@RequestBody @Validated ListRecentSokxayRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "list transactions recent Sokxay", "0", "0"));
        return new ResponseEntity<>(iSokxay.listRecentSokxay(request), HttpStatus.OK);
    }
    @PostMapping("/confirm-sokxay")
    public ResponseEntity<Object> confirmSokxay(@RequestBody @Validated ConfirmSokxayRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "confirm transaction sokxay", "0", "0"));
        return new ResponseEntity<>(iSokxay.confirmSokxay(request), HttpStatus.OK);
    }
}
