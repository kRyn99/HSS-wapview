/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to control transfer to non-umoney businesses.
 */
package com.sta.unitel.controller;

import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.inteface.transfer_to_non_umoney.ITransferToNonUMoney;
import com.sta.unitel.inteface.transfer_to_non_umoney.request.CheckNonUMoneyRequest;
import com.sta.unitel.inteface.transfer_to_non_umoney.request.ConfirmTransferToNonUMoneyRequest;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/transfer-to-non-umoney")
@CrossOrigin("*")
public class TransferToNonUMoneyController {

    private final ITransferToNonUMoney iTransferToNonUMoney;
    private final ITransactions iTransactions;

    public TransferToNonUMoneyController(ITransferToNonUMoney iTransferToNonUMoney, ITransactions iTransactions) {
        this.iTransferToNonUMoney = iTransferToNonUMoney;
        this.iTransactions =iTransactions;
    }

    @PostMapping("/check")
    public ResponseEntity<Object> checkAccountUMoney(@RequestBody @Validated CheckNonUMoneyRequest request) {
        iTransactions.save(new Transaction("U-Money","Get info of receiver (Non u-money)","0","0" ));
        return new ResponseEntity<>(iTransferToNonUMoney.checkInfo(request), HttpStatus.OK);
    }

    @PostMapping("/confirm")
    public ResponseEntity<Object> confirmTrans(@RequestBody @Validated ConfirmTransferToNonUMoneyRequest request)
    {
        iTransactions.save(new Transaction("U-Money","Confirm transfer to non u-money","0","0" ));
        return new ResponseEntity<>(iTransferToNonUMoney.confirmTrans(request), HttpStatus.OK);
    }
}
