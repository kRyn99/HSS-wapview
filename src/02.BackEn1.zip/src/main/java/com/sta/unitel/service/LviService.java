package com.sta.unitel.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.lvi.ILvi;
import com.sta.unitel.inteface.lvi.request.ConfirmVehicleRequest;
import com.sta.unitel.inteface.lvi.request.LviDeliveryListRequest;
import com.sta.unitel.inteface.lvi.request.LviPackageDetailRequest;
import com.sta.unitel.inteface.lvi.request.LviPackagesRequest;
import com.sta.unitel.inteface.lvi.request.LviVehicleListRequest;
import com.sta.unitel.inteface.lvi.request.VehicleCheckRequest;
import com.sta.unitel.inteface.lvi.request.AccidentCheckRequest;
import com.sta.unitel.inteface.lvi.request.ConfirmAccidentRequest;
import com.sta.unitel.utils.RsaUtil;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Objects;

@Service
public class LviService implements ILvi {
    @Value("${prefix-url-service}")
    private String prefix_service_url;

    private static final String ACCEPT_LANG = "Accept-Language";
    private static final String COMMON_URL = "mobileservice/api/partner/v2.0/";

    private final ObjectMapper mapper;
    private ICommons iCommons;

    public LviService(ObjectMapper mapper, ICommons iCommons) {
        this.mapper = mapper;
        this.iCommons = iCommons;
    }

    @Override
    public NativeRes confirmVehicle(ConfirmVehicleRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/customer/v2.0/lvi/insurance-vehicle/confirm";
        HttpHeaders headersConfirmVehicle = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersConfirmVehicle.set(ACCEPT_LANG, request.getLang());
        headersConfirmVehicle.set("checkSum", "u-money");
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersConfirmVehicle);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes lviDeliveryList(LviDeliveryListRequest request) {
        final String uri = prefix_service_url + COMMON_URL +
                "lvi/delivery/list?phoneNumber=%s&token=%s";
        String url = String.format(uri, request.getPhoneNumber(), request.getToken());
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        if (request.getToken() == null || request.getToken().equals("")) {
            Gson g = new Gson();
            try {
                ClassLoader classLoader = getClass().getClassLoader();
                String fileName = "";
                switch (request.getLang()) {
                    case "en":
                        fileName = "public/lvi_delivery/lvi_list_delivery_en.json";
                        break;
                    case "vi":
                        fileName = "public/lvi_delivery/lvi_list_delivery_vi.json";
                        break;
                    case "lo":
                        fileName = "public/lvi_delivery/lvi_list_delivery_lo.json";
                        break;
                    case "zh":
                        fileName = "public/lvi_delivery/lvi_list_delivery_zh.json";
                        break;
                }
                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
                String content = new String(Files.readAllBytes(file.toPath()));
                return g.fromJson(content, NativeRes.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        httpHeaders.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes lviPackages(LviPackagesRequest request) {
        final String uri = prefix_service_url + COMMON_URL +
                "lvi/insurance/packages?phoneNumber=%s&token=%s&type=%s";
        String url = String.format(uri, request.getPhoneNumber(), request.getToken(), request.getType());
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        if (request.getToken() == null || request.getToken().equals("")) {
            Gson g = new Gson();
            try {
                ClassLoader classLoader = getClass().getClassLoader();
                String fileName = "";
                if (request.getType() == 0) {

                    switch (request.getLang()) {
                        case "en":
                            fileName = "public/lvi_packages/lvi_packages_buy_new_en.json";
                            break;
                        case "vi":
                            fileName = "public/lvi_packages/lvi_packages_buy_new_vi.json";
                            break;
                        case "lo":
                            fileName = "public/lvi_packages/lvi_packages_buy_new_lo.json";
                            break;
                        case "zh":
                            fileName = "public/lvi_packages/lvi_packages_buy_new_zh.json";
                            break;
                    }
                } else if (request.getType() == 1) {
                    switch (request.getLang()) {
                        case "en":
                            fileName = "public/lvi_packages/lvi_packages_healthy_en.json";
                            break;
                        case "vi":
                            fileName = "public/lvi_packages/lvi_packages_healthy_vi.json";
                            break;
                        case "lo":
                            fileName = "public/lvi_packages/lvi_packages_healthy_lo.json";
                            break;
                        case "zh":
                            fileName = "public/lvi_packages/lvi_packages_healthy_zh.json";
                            break;
                    }
                }

                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
                String content = new String(Files.readAllBytes(file.toPath()));
                return g.fromJson(content, NativeRes.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        httpHeaders.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes lviPackageDetail(LviPackageDetailRequest request) {
        final String uri = prefix_service_url + COMMON_URL +
                "lvi/insurance/package/detail?packageCode=%s&phoneNumber=%s&token=%s&type=%s";
        String url = String.format(uri, request.getPackageCode(), request.getPhoneNumber(),
                request.getToken(), request.getType());
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        if (request.getToken() == null || request.getToken().equals("")) {
            Gson g = new Gson();
            try {
                ClassLoader classLoader = getClass().getClassLoader();
                String fileName = "";
                if (request.getType() == 0) {
                    switch (request.getPackageCode()) {
                        case "A0":
                            switch (request.getLang()) {
                                case "en":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a0_en.json";
                                    break;
                                case "vi":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a0_vi.json";
                                    break;
                                case "lo":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a0_lo.json";
                                    break;
                                case "zh":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a0_zh.json";
                                    break;
                            }
                            break;
                        case "A1":
                            switch (request.getLang()) {
                                case "en":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a1_en.json";
                                    break;
                                case "vi":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a1_vi.json";
                                    break;
                                case "lo":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a1_lo.json";
                                    break;
                                case "zh":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a1_zh.json";
                                    break;
                            }
                            break;
                        case "A2":
                            switch (request.getLang()) {
                                case "en":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a2_en.json";
                                    break;
                                case "vi":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a2_vi.json";
                                    break;
                                case "lo":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a2_lo.json";
                                    break;
                                case "zh":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_new_a2_zh.json";
                                    break;
                            }
                            break;
                    }
                }
                else if (request.getType() == 1) {
                    switch (request.getPackageCode()) {
                        case "PA01":
                            switch (request.getLang()) {
                                case "en":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa01_en.json";
                                    break;
                                case "vi":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa01_vi.json";
                                    break;
                                case "lo":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa01_lo.json";
                                    break;
                                case "zh":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa01_zh.json";
                                    break;
                            }
                            break;
                        case "PA02":
                            switch (request.getLang()) {
                                case "en":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa02_en.json";
                                    break;
                                case "vi":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa02_vi.json";
                                    break;
                                case "lo":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa02_lo.json";
                                    break;
                                case "zh":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa02_zh.json";
                                    break;
                            }
                            break;
                        case "PA03":
                            switch (request.getLang()) {
                                case "en":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa03_en.json";
                                    break;
                                case "vi":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa03_vi.json";
                                    break;
                                case "lo":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa03_lo.json";
                                    break;
                                case "zh":
                                    fileName = "public/lvi_package_detail/lvi_package_detail_healthy_pa03_zh.json";
                                    break;
                            }
                            break;
                    }
                }
                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
                String content = new String(Files.readAllBytes(file.toPath()));
                return g.fromJson(content, NativeRes.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        httpHeaders.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes lviVehicleList(LviVehicleListRequest request) {
        final String uri = prefix_service_url + COMMON_URL +
                "lvi/vehicle/list?phoneNumber=%s&token=%s";
        String url = String.format(uri, request.getPhoneNumber(), request.getToken());
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        if (request.getToken() == null || request.getToken().equals("")) {
            Gson g = new Gson();
            try {
                ClassLoader classLoader = getClass().getClassLoader();
                String fileName = "";
                switch (request.getLang()) {
                    case "en":
                        fileName = "public/lvi_vehicle/lvi_list_vehicle_en.json";
                        break;
                    case "vi":
                        fileName = "public/lvi_vehicle/lvi_list_vehicle_vi.json";
                        break;
                    case "lo":
                        fileName = "public/lvi_vehicle/lvi_list_vehicle_lo.json";
                        break;
                    case "zh":
                        fileName = "public/lvi_vehicle/lvi_list_vehicle_zh.json";
                        break;
                }
                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
                String content = new String(Files.readAllBytes(file.toPath()));
                return g.fromJson(content, NativeRes.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        httpHeaders.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes lviVehicleCheck(VehicleCheckRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/policy/v2.0/lvi/insurance-vehicle/check";
        HttpHeaders headersVehicleCheck = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersVehicleCheck.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersVehicleCheck);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes lviAccidentCheck(AccidentCheckRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/policy/v2.0/lvi/insurance-accident/check";
        HttpHeaders headersAccidentCheck = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersAccidentCheck.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersAccidentCheck);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes uploadFile(MultipartFile file) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/file/upload";
        CloseableHttpClient httpClient = HttpClients.custom().setSSLHostnameVerifier
                (new NoopHostnameVerifier()).build();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);
        RestTemplate restTemplate = new RestTemplate(requestFactory);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set("directory", "lvi");
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("file", file.getResource());
        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(params, headers);
        String error;
        try {
            ResponseEntity<NativeRes> response = restTemplate.exchange(
                    uri, HttpMethod.POST, httpEntity, NativeRes.class);
            return response.getBody();
        } catch (HttpStatusCodeException exception) {
            error = exception.getResponseBodyAsString();
            try {
                return mapper.readValue(error, NativeRes.class);
            } catch (JsonProcessingException e) {
                throw new IllegalArgumentException(e);
            }
        }
    }

    @Override
    public NativeRes confirmAccident(ConfirmAccidentRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/customer/v2.0/lvi/insurance-accident/confirm";
        HttpHeaders headersConfirmAccident = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersConfirmAccident.set(ACCEPT_LANG, request.getLang());
        headersConfirmAccident.set("checkSum", "u-money");
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersConfirmAccident);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }
}
