/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "view list of transactions recently" API.
 */
package com.sta.unitel.inteface.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class TransactionRecentDto {
    private String actionId;
    private String transactionId;
    private String processCode;
    private String transactionName;
    private String fromName;
    private String toName;
    private Long amount;
    private Byte type;
    private String dateTime;
    private String currencyCode;
    private String fromPhone;
    private String toPhone;
    private String partnerCode;
    private String serviceCode;
}
