/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "view list of banks that allow to transfer through u-money" API.
 */
package com.sta.unitel.inteface.transfer_to_banks.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ListBankDto {
    private String bankId;
    private String bankCode;
    private String bankName;
    private String partnerCode;
    private String imageUrl;
    private String visibility;
}
