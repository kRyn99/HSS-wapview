/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to control top-up businesses.
 */
package com.sta.unitel.controller;

import com.sta.unitel.inteface.topup.ITopUp;
import com.sta.unitel.inteface.topup.request.CheckInfoTopUpRequest;
import com.sta.unitel.inteface.topup.request.ConfirmTransactionTopUpRequest;
import com.sta.unitel.inteface.topup.request.TopUpRecentRequest;
import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@RequestMapping("/api/v1/top-up")
@CrossOrigin("*")
public class TopUpController {
    private static final String U_MONEY = "U-Money";
    private final ITopUp iTopUp;
    private final ITransactions iTransactions;
    public TopUpController(ITopUp iTopUp, ITransactions iTransactions)
    {
        this.iTopUp = iTopUp;
        this.iTransactions = iTransactions;
    }

    @PostMapping("/check-topup")
    public ResponseEntity<Object> checkInfoTopUp(@RequestBody @Validated CheckInfoTopUpRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Get ISDN Top-up","0","0" ));
        return new ResponseEntity<>(iTopUp.checkInfoTopUp(request), HttpStatus.OK);
    }

    @PostMapping("/confirm-topup")
    public ResponseEntity<Object> confirmTransactionTopUp(@RequestBody @Validated
                                                                      ConfirmTransactionTopUpRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Confirm transaction top-up","0","0" ));
        return new ResponseEntity<>(iTopUp.confirmTransactionTopUp(request), HttpStatus.OK);
    }

    @PostMapping("/topup-recent")
    public ResponseEntity<Object> getListTopUpRecent(@RequestBody @Validated TopUpRecentRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Get list of Top-up transactions recently","0","0" ));
        return new ResponseEntity<>(iTopUp.getListTopUpRecent(request, request.getLimit(), request.getOffset(),
                request.getPhoneNumber(), request.getRoleId(), request.getToken()), HttpStatus.OK);
    }
}
