package com.sta.unitel.inteface.lvi.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class LviPackageDetailRequest {
    private String packageCode;
    private String phoneNumber;
    private String token;
    private Integer type;
    private String lang;
}
