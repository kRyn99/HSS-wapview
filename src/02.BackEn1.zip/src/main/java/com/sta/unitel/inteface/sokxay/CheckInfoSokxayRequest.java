package com.sta.unitel.inteface.sokxay;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CheckInfoSokxayRequest {
    private List<Lottery> listLottery;
    private String phoneNumber;
    private String lang;
}
