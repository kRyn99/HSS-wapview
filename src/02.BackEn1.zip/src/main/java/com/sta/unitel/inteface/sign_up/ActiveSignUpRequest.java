package com.sta.unitel.inteface.sign_up;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ActiveSignUpRequest {
    private String otp;
    private String phoneNumber;
    private String pin;
    private String roleId;
    private String lang;
    private String deviceId;
}
