package com.sta.unitel.inteface.lvi;

import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.lvi.request.AccidentCheckRequest;
import com.sta.unitel.inteface.lvi.request.ConfirmAccidentRequest;
import com.sta.unitel.inteface.lvi.request.ConfirmVehicleRequest;
import com.sta.unitel.inteface.lvi.request.VehicleCheckRequest;
import com.sta.unitel.inteface.lvi.request.LviDeliveryListRequest;
import com.sta.unitel.inteface.lvi.request.LviPackagesRequest;
import com.sta.unitel.inteface.lvi.request.LviPackageDetailRequest;
import com.sta.unitel.inteface.lvi.request.LviVehicleListRequest;
import org.springframework.web.multipart.MultipartFile;

public interface ILvi {
    NativeRes confirmVehicle(ConfirmVehicleRequest request);
    NativeRes lviDeliveryList(LviDeliveryListRequest request);
    NativeRes lviPackages(LviPackagesRequest request);
    NativeRes lviPackageDetail(LviPackageDetailRequest request);
    NativeRes lviVehicleList(LviVehicleListRequest request);
    NativeRes lviVehicleCheck(VehicleCheckRequest request);
    NativeRes lviAccidentCheck(AccidentCheckRequest request);
    NativeRes uploadFile(MultipartFile file);
    NativeRes confirmAccident(ConfirmAccidentRequest request);
}
