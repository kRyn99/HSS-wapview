/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to encrypt some important fields such as pin, otp (using RSA algorithm).
 */
package com.sta.unitel.utils;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;


public class RsaUtil {

    private RsaUtil() {
        throw new IllegalStateException("Utility class");
    }

    static final String PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCyrpu+fDcb" +
            "JZTwE9qAHVw0fWkpzmZNjUP6MIMi31hhjqvR1DanCgyVtM2IiVGSSUnmarZ48B0kl5HVlpZ8mV3ztGGyn8NGjlna+a7zcvr1" +
            "tEy9qn7Q0nHPjHUXSBV0LqPnfQb4phsW2FmCa97vf+IrXwdVib0cqWzoGpINOO8mfwIDAQAB";

    public static String getEncrypted(String data) {
        Cipher cipher = null;
        try {
            cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new IllegalArgumentException(e);
        }
        PublicKey publicKey = null;
        try {
            publicKey = KeyFactory.getInstance("RSA")
                    .generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(PUBLIC_KEY.getBytes())));
        } catch (InvalidKeySpecException | NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        }
        try {
            assert cipher != null;
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        } catch (InvalidKeyException e) {
            throw new IllegalArgumentException(e);
        }
        byte[] encryptedBytes = new byte[0];
        try {
            encryptedBytes = cipher.doFinal(data.getBytes());
        } catch (IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
        return new String(Base64.getEncoder().encode(encryptedBytes));
    }
}

