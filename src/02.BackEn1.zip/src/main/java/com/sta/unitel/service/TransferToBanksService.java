/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to implement the methods that defined in ITransferToBank interface.
 */
package com.sta.unitel.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.transfer_to_banks.ITransferToBanks;
import com.sta.unitel.inteface.transfer_to_banks.dto.ListBankDto;
import com.sta.unitel.inteface.transfer_to_banks.request.CheckAccountRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.CheckOnlyBankAccountNoRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.ConfirmTransferToBanksRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.ListBankRequest;
import com.sta.unitel.utils.RsaUtil;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@Service
public class TransferToBanksService implements ITransferToBanks {

    @Value("${prefix-url-service}")
    private String prefix_service_url;
    private static final String ACCEPT_LANG = "Accept-Language";
    private ICommons iCommons;

    public TransferToBanksService(ICommons iCommons) {
        this.iCommons = iCommons;
    }

    @Override
    public NativeRes getApiListBank(ListBankRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/bank/v2.0/listBank?phoneNumber=%s&token=%s";
        HttpHeaders headersListBank = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        if (request.getToken() == null || request.getToken().equals("")) {
//            Gson g = new Gson();
//            try {
//                ClassLoader classLoader = getClass().getClassLoader();
//                String fileName = "public/list_bank.json";
//                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
//                String content = new String(Files.readAllBytes(file.toPath()));
//                return g.fromJson(content, NativeRes.class);
//                InputStream inJson = NativeRes.class.getResourceAsStream("/public/list_bank.json");
//                return new ObjectMapper().readValue(inJson, NativeRes.class);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
            List<ListBankDto> bankDtoList = new ArrayList<>();
            bankDtoList.add(new ListBankDto("1", "BCEL", "Banque pour le Commerce Exterieur Lao Public",
                    "BANK_BCEL", "https://mobile.unitel.com.la:8089/cms-backend/cms/file/v1.0/image/logo_bcel.png",
                    "VISIBLE"));
            bankDtoList.add(new ListBankDto("7", "JDB", "Joint Development Bank",
                    "BANK_JDB", "https://mobile.unitel.com.la:8089/cms-backend/cms/file/v1.0/image/logo_jdbbank.png",
                    "VISIBLE"));
            bankDtoList.add(new ListBankDto("3", "LVB", "Lao Viet Joint Venture Bank",
                    "BANK_LVB", "https://mobile.unitel.com.la:8089/cms-backend/cms/file/v1.0/image/logo_laovietbank.png",
                    "VISIBLE"));
            bankDtoList.add(new ListBankDto("6", "MRH", "Maruhan Bank",
                    "BANK_MRH", "https://mobile.unitel.com.la:8089/cms-backend/cms/file/v1.0/image/logo_maruhanbank.png",
                    "VISIBLE"));
            return new NativeRes(200, "Get list bank successful", bankDtoList);
        }
        headersListBank.set(ACCEPT_LANG, request.getLang());
        String url = String.format(uri, request.getPhoneNumber(), request.getToken());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersListBank);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes checkAccount(CheckAccountRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/policy/v2.0/eu/transfer-bank/check";
        HttpHeaders headersCheckBank = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersCheckBank.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersCheckBank);

        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes checkOnlyBankAccountNo(CheckOnlyBankAccountNoRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/bank/v2.0/account/info";
        HttpHeaders headersCheckBankNoFee = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersCheckBankNoFee.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersCheckBankNoFee);

        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes confirmBank(ConfirmTransferToBanksRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/customer/v2.0/transfer-bank/confirm";
        HttpHeaders headersConfirmBank = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersConfirmBank.set(ACCEPT_LANG, request.getLang());
        headersConfirmBank.set("checkSum", "u-money");
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersConfirmBank);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }
}
