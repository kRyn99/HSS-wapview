package com.sta.unitel.service;

import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.sokxay.CheckInfoSokxayRequest;
import com.sta.unitel.inteface.sokxay.ConfirmSokxayRequest;
import com.sta.unitel.inteface.sokxay.ISokxay;
import com.sta.unitel.inteface.sokxay.ListRecentSokxayRequest;
import com.sta.unitel.utils.RsaUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class SokxayService implements ISokxay {
    @Value("${prefix-url-service}")
    private String prefix_service_url;
    private static final String ACCEPT_LANG = "Accept-Language";

    private ICommons iCommons;

    public SokxayService(ICommons iCommons) {
        this.iCommons = iCommons;
    }

    @Override
    public NativeRes checkInfoSokxay(CheckInfoSokxayRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/policy/v2.0/eu/sokxay-lottery/check";
        HttpHeaders headersCheckSokxay = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersCheckSokxay.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntityCheck = new HttpEntity<>(request, headersCheckSokxay);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntityCheck);
    }

    @Override
    public NativeRes listRecentSokxay(ListRecentSokxayRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/sokxay-lottery/history?" +
                "phoneNumber=%s&token=%s";
        String url = String.format(uri, request.getPhoneNumber(), request.getToken());
        HttpHeaders headersRecentSokxay = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersRecentSokxay.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersRecentSokxay);
        return iCommons.getApiBase(HttpMethod.PUT, url, httpEntity);
    }

    @Override
    public NativeRes confirmSokxay(ConfirmSokxayRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/customer/v2.0/sokxay-lottery/confirm";
        HttpHeaders headersConfirmSokxay = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersConfirmSokxay.set(ACCEPT_LANG, request.getLang());
        headersConfirmSokxay.set("checkSum", "u-money");
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersConfirmSokxay);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

//    @Override
//    public NativeRes1<ConfirmSokxayDto> confirmSokxay(ConfirmSokxayRequest request) {
//        if (request.getOtp().equals("222222")) {
//            return new NativeRes1<>(200, "Transaction successfully", new ConfirmSokxayDto("00000",
//                    "Transaction successfully.",
//                    "210106000170760",
//                    "15:28 06/01/2021",
//                    false, "2402770509"));
//        } else {
//            return new NativeRes1<>(403, "The OTP is invalid", new ConfirmSokxayDto("10003",
//                    "The OTP is invalid.",
//                    "210302000188760",
//                    "13:38 02/03/2021",
//                    false, ""));
//        }
//    }
}
