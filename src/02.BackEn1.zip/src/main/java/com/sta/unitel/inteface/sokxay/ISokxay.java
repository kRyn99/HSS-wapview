package com.sta.unitel.inteface.sokxay;

import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.commons.dto.NativeRes1;

public interface ISokxay {
    NativeRes checkInfoSokxay(CheckInfoSokxayRequest request);
    NativeRes listRecentSokxay(ListRecentSokxayRequest request);
    NativeRes confirmSokxay(ConfirmSokxayRequest request);
//    NativeRes1<ConfirmSokxayDto> confirmSokxay(ConfirmSokxayRequest request);
}
