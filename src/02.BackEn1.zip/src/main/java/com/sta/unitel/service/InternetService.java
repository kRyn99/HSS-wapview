/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to implement the methods that defined in IInternet interface.
 */
package com.sta.unitel.service;

import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.internet.CheckInfoInternetRequest;
import com.sta.unitel.inteface.internet.IInternet;
import com.sta.unitel.inteface.internet.InternetRequest;
import com.sta.unitel.utils.RsaUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class InternetService implements IInternet {
    @Value("${prefix-url-service}")
    private String prefix_service_url;
    private ICommons iCommons;

    public InternetService(ICommons iCommons)
    {
        this.iCommons = iCommons;
    }
    @Override
    public NativeRes confirmInternet(InternetRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/customer/v2.0/internet-payment/confirm";
        HttpHeaders httpHeadersConfirmInternet = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        httpHeadersConfirmInternet.set("Accept-Language", request.getLang());
        httpHeadersConfirmInternet.set("checkSum", "u-money");
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeadersConfirmInternet);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes checkInfoInternet(CheckInfoInternetRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/policy/v2.0/internet-payment/check";
        HttpHeaders headersCheck = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersCheck.set("Accept-Language", request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersCheck);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }
}
