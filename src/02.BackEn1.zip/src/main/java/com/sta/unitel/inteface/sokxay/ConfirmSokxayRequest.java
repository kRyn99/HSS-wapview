package com.sta.unitel.inteface.sokxay;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ConfirmSokxayRequest {
    private List<Lottery> listLottery;
    private String otp;
    private String phoneNumber;
    private String pin;
    private String lang;
}
