package com.sta.unitel.inteface.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FieldMapRequet {
    private Integer fieldID;
    private String value;

}
