package com.sta.unitel.controller;

import com.sta.unitel.inteface.sign_up.CheckSignUpConditionRequest;
import com.sta.unitel.inteface.sign_up.ConfirmSignUpRequest;
import com.sta.unitel.inteface.sign_up.ISignUp;
import com.sta.unitel.inteface.sign_up.OtpSignUpRequest;
import com.sta.unitel.inteface.sign_up.ActiveSignUpRequest;
import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@RequestMapping("/api/v1/sign-up")
@CrossOrigin("*")
public class SignUpController {
    private static final String U_MONEY = "U-Money";
    private final ISignUp iSignUp;
    private final ITransactions iTransactions;

    public SignUpController(ISignUp iSignUp, ITransactions iTransactions) {
        this.iSignUp = iSignUp;
        this.iTransactions = iTransactions;
    }

    @PostMapping("/otp-signUp")
    public ResponseEntity<Object> getOtpSignUp(@RequestBody @Validated OtpSignUpRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"check sign up condition of phoneNumber","0","0" ));
        return new ResponseEntity<>(iSignUp.getOtpSignUp(request), HttpStatus.OK);
    }
    @PostMapping("/check-signUp-condition")
    public ResponseEntity<Object> checkSignUpCondition(@RequestBody @Validated CheckSignUpConditionRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"check sign up condition of phoneNumber","0","0" ));
        return new ResponseEntity<>(iSignUp.checkSignUpCondition(request), HttpStatus.OK);
    }
    @PostMapping("/confirm-signUp")
    public ResponseEntity<Object> confirmSignUp(@RequestBody @Validated ConfirmSignUpRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"confirm sign up process","0","0" ));
        return new ResponseEntity<>(iSignUp.confirmSignUp(request), HttpStatus.OK);
    }
    @PostMapping("/active-signUp")
    public ResponseEntity<Object> confirmSignUp(@RequestBody @Validated ActiveSignUpRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"active E-Wallet account","0","0" ));
        return new ResponseEntity<>(iSignUp.activeSignUp(request), HttpStatus.OK);
    }
}
