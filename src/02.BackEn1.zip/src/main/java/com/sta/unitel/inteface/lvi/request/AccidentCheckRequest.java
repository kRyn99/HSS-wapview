package com.sta.unitel.inteface.lvi.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AccidentCheckRequest {
    private String phoneNumber;
    private String packageCode;
    private String dateOfBirth;
    private String lang;
}
