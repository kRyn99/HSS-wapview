package com.sta.unitel.controller;

import com.sta.unitel.inteface.lvi.ILvi;
import com.sta.unitel.inteface.lvi.request.AccidentCheckRequest;
import com.sta.unitel.inteface.lvi.request.ConfirmAccidentRequest;
import com.sta.unitel.inteface.lvi.request.ConfirmVehicleRequest;
import com.sta.unitel.inteface.lvi.request.VehicleCheckRequest;
import com.sta.unitel.inteface.lvi.request.LviDeliveryListRequest;
import com.sta.unitel.inteface.lvi.request.LviPackagesRequest;
import com.sta.unitel.inteface.lvi.request.LviPackageDetailRequest;
import com.sta.unitel.inteface.lvi.request.LviVehicleListRequest;
import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v1/lvi")
@CrossOrigin("*")
public class LviController {
    private final String U_MONEY = "U-Money";
    private final ILvi iLvi;
    private final ITransactions iTransactions;

    public LviController(ILvi iLvi, ITransactions iTransactions) {
        this.iLvi = iLvi;
        this.iTransactions = iTransactions;
    }

    @PostMapping("/confirm-vehicle")
    public ResponseEntity<Object> confirmVehicle(@RequestBody @Validated ConfirmVehicleRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "confirm lvi vehicle transaction", "0", "0"));
        return new ResponseEntity<>(iLvi.confirmVehicle(request), HttpStatus.OK);
    }

    @PostMapping("/confirm-accident")
    public ResponseEntity<Object> confirmAccident(@RequestBody @Validated ConfirmAccidentRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "confirm lvi accident transaction", "0", "0"));
        return new ResponseEntity<>(iLvi.confirmAccident(request), HttpStatus.OK);
    }

    @PostMapping("/check-vehicle")
    public ResponseEntity<Object> lviVehicleCheck(@RequestBody @Validated VehicleCheckRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "check lvi vehicle transaction", "0", "0"));
        return new ResponseEntity<>(iLvi.lviVehicleCheck(request), HttpStatus.OK);
    }

    @PostMapping("/check-accident")
    public ResponseEntity<Object> lviAccidentCheck(@RequestBody @Validated AccidentCheckRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "check lvi accident transaction", "0", "0"));
        return new ResponseEntity<>(iLvi.lviAccidentCheck(request), HttpStatus.OK);
    }

    @PostMapping("/delivery-list")
    public ResponseEntity<Object> lviDeliveryList(@RequestBody @Validated LviDeliveryListRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "get delivery list", "0", "0"));
        return new ResponseEntity<>(iLvi.lviDeliveryList(request), HttpStatus.OK);
    }

    @PostMapping("/packages")
    public ResponseEntity<Object> lviPackages(@RequestBody @Validated LviPackagesRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "get list packages", "0", "0"));
        return new ResponseEntity<>(iLvi.lviPackages(request), HttpStatus.OK);
    }

    @PostMapping("/package-detail")
    public ResponseEntity<Object> lviPackageDetail(@RequestBody @Validated LviPackageDetailRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "get package detail", "0", "0"));
        return new ResponseEntity<>(iLvi.lviPackageDetail(request), HttpStatus.OK);
    }

    @PostMapping("/vehicle-list")
    public ResponseEntity<Object> lviVehicleList(@RequestBody @Validated LviVehicleListRequest request) {
        iTransactions.save(new Transaction(U_MONEY, "get list vehicle", "0", "0"));
        return new ResponseEntity<>(iLvi.lviVehicleList(request), HttpStatus.OK);
    }

    @PostMapping(value = "/upload-file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file) {
        iTransactions.save(new Transaction(U_MONEY, "upload image file ", "0", "0"));
        return new ResponseEntity<>(iLvi.uploadFile(file), HttpStatus.OK);
    }
}
