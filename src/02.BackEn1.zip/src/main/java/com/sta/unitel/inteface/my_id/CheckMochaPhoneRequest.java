package com.sta.unitel.inteface.my_id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Positive;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CheckMochaPhoneRequest {
    //    private Long amount;
//    private String content;
    private String phoneNumber;
    private String toPhone;
    private String lang;
}
