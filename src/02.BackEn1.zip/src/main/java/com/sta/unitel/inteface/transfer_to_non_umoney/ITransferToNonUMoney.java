/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to declare some abstract methods of transfer to non-umoney businesses.
 */
package com.sta.unitel.inteface.transfer_to_non_umoney;

import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.transfer_to_non_umoney.request.CheckNonUMoneyRequest;
import com.sta.unitel.inteface.transfer_to_non_umoney.request.ConfirmTransferToNonUMoneyRequest;

public interface ITransferToNonUMoney {
    NativeRes checkInfo(CheckNonUMoneyRequest request);
    NativeRes confirmTrans(ConfirmTransferToNonUMoneyRequest request);
}
