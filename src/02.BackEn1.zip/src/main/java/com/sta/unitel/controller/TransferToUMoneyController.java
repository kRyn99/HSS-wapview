/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to control transfer to u-money businesses.
 */
package com.sta.unitel.controller;

import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.inteface.transfer_to_umoney.ITransferToUMoney;
import com.sta.unitel.inteface.transfer_to_umoney.request.CheckAccountUMoneyRequest;
import com.sta.unitel.inteface.transfer_to_umoney.request.ConfirmTransferToUMoneyRequest;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
@RestController
@RequestMapping("/api/v1/transfer-to-umoney")
@CrossOrigin("*")
public class TransferToUMoneyController {

    private final ITransferToUMoney iTransferToUMoney;
    private final ITransactions iTransactions;

    public TransferToUMoneyController(ITransferToUMoney iTransferToUMoney, ITransactions iTransactions) {
        this.iTransferToUMoney = iTransferToUMoney;
        this.iTransactions = iTransactions;
    }

    @PostMapping("/check")
    public ResponseEntity<Object> checkAccountUMoney(@RequestBody @Validated CheckAccountUMoneyRequest request)
    {
        iTransactions.save(new Transaction("U-Money","Get info of receiver (U-money)","0","0" ));
        return new ResponseEntity<>(iTransferToUMoney.checkAccountUMoneyInfo(request), HttpStatus.OK);
    }

    @PostMapping("/check-umoney/mocha")
    public ResponseEntity<Object> checkAccountMocha(@RequestBody @Validated CheckAccountUMoneyRequest request)
    {
        iTransactions.save(new Transaction("U-Money","Check if Mocha phone number has registered" +
                "u-money service or not","0","0" ));
        return new ResponseEntity<>(iTransferToUMoney.checkAccountMocha(request), HttpStatus.OK);
    }

    @PostMapping("/confirm")
    public ResponseEntity<Object> confirmTrans(@RequestBody @Validated ConfirmTransferToUMoneyRequest request)
    {
        iTransactions.save(new Transaction("U-Money","Confirm transfer to u-money","0","0" ));
        return new ResponseEntity<>(iTransferToUMoney.confirmTrans(request), HttpStatus.OK);
    }

}
