package com.sta.unitel.inteface.electric_bill;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CheckPolicyElectricRequest {
    private String account;
    private String branchCode;
    private String partnerCode;
    private String phoneNumber;
    private Long amount;
    private String lang;
}
