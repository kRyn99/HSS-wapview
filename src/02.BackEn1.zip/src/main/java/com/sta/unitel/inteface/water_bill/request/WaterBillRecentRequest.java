/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define some fields of request for "get list of water bill transaction recent" API.
 */
package com.sta.unitel.inteface.water_bill.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class WaterBillRecentRequest {
    private String limit;
    private String offset;
    private String phoneNumber;
    private String roleId;
    private String token;
    private String partnerCode;
    private String processCode;
    private String lang;
}
