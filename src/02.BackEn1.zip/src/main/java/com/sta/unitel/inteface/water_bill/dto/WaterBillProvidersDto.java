/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "get list of water bill providers" API.
 */
package com.sta.unitel.inteface.water_bill.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class WaterBillProvidersDto {
    private String name;
    private String imageUrl;
    private String partnerCode;
    private String visibility;
}
