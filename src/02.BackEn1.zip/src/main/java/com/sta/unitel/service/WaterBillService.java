/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to implement the methods that defined in IWaterBill interface.
 */
package com.sta.unitel.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.water_bill.IWaterBill;
import com.sta.unitel.inteface.water_bill.request.CheckWaterBillRequest;
import com.sta.unitel.inteface.water_bill.request.ConfirmWaterBillRequest;
import com.sta.unitel.inteface.water_bill.request.WaterBillProvidersRequest;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;
import com.sta.unitel.utils.RsaUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Objects;

@Service
public class WaterBillService implements IWaterBill {
    @Value("${prefix-url-service}")
    private String prefix_service_url;
    private static final String ACCEPT_LANG = "Accept-Language";

    private ICommons iCommons;

    public WaterBillService(ICommons iCommons)
    {
        this.iCommons = iCommons;
    }

    @Override
    public NativeRes checkWaterBill(CheckWaterBillRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/partner/v2.0/account/info";
        HttpHeaders headersCheckWater = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersCheckWater.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersCheckWater);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes confirmWaterBill(ConfirmWaterBillRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/partner/v2.0/payment/confirm";
        HttpHeaders headersConfirmWater = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        headersConfirmWater.set(ACCEPT_LANG, request.getLang());
        request.setOtp(RsaUtil.getEncrypted(request.getOtp()));
        request.setPin(RsaUtil.getEncrypted(request.getPin()));
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersConfirmWater);
        return iCommons.getApiBase(HttpMethod.POST, uri, httpEntity);
    }

    @Override
    public NativeRes getListWaterBillProviders(WaterBillProvidersRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/partner/v2.0/" +
                "list?phoneNumber=%s&roleId=%s&token=%s&type=%s";
        String url = String.format(uri, request.getPhoneNumber(),
                request.getRoleId(), request.getToken(), request.getType());
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null){
            request.setLang("en");
        }
        request.setType("WATER");
        if (request.getToken() == null || request.getToken().equals("")) {
            Gson g = new Gson();
            try {
                ClassLoader classLoader = getClass().getClassLoader();
                String fileName = "public/list_water_providers.json";
                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
                String content = new String(Files.readAllBytes(file.toPath()));
                return g.fromJson(content, NativeRes.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        httpHeaders.set(ACCEPT_LANG, request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes getListWaterBillTransRecent(@RequestBody WaterBillRecentRequest request, String limit,
                                                 String offset, String phoneNumber, String roleId, String token) {
        final String uri = prefix_service_url + "mobileservice/api/common/v2.0/" +
                "trans-recent?limit=%s&offset=%s&phoneNumber=%s&roleId=%s&token=%s";
        HttpHeaders headersRecentWater = new HttpHeaders();
        if (request.getLang() == null){
            request.setLang("en");
        }
        headersRecentWater.set(ACCEPT_LANG, request.getLang());
        String url = String.format(uri, limit, offset, phoneNumber, roleId, token);
        request.setPartnerCode("PAYMENT_WATTER_NPP");
        request.setProcessCode("600101");
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, headersRecentWater);
        return iCommons.getApiBase(HttpMethod.PUT, url, httpEntity);
    }
}
