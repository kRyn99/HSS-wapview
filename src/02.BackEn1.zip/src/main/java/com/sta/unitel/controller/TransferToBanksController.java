/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to control transfer to bank businesses.
 */
package com.sta.unitel.controller;

import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.inteface.transfer_to_banks.ITransferToBanks;
import com.sta.unitel.inteface.transfer_to_banks.request.CheckAccountRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.CheckOnlyBankAccountNoRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.ConfirmTransferToBanksRequest;
import com.sta.unitel.inteface.transfer_to_banks.request.ListBankRequest;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/transfer-to-bank")
@CrossOrigin("*")
public class TransferToBanksController
{
    private static final String U_MONEY = "U-Money";
    private final ITransferToBanks iTransferToBanks;
    private final ITransactions iTransactions;

    public TransferToBanksController(ITransferToBanks iTransferToBanks, ITransactions iTransactions)
    {
        this.iTransferToBanks = iTransferToBanks;
        this.iTransactions = iTransactions;
    }

    @GetMapping("/list-bank")
    public ResponseEntity<Object> listBank(@Validated ListBankRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"View list of banks", "0","0" ));
        return new ResponseEntity<>(iTransferToBanks.getApiListBank(request), HttpStatus.OK);
    }

    @PostMapping("/confirm-bank")
    public ResponseEntity<Object> infoBank(@RequestBody @Validated ConfirmTransferToBanksRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Confirm transfer to bank", "0","0" ));
        return new ResponseEntity<>(iTransferToBanks.confirmBank(request), HttpStatus.OK);
    }

    @PostMapping("/check-account")
    public ResponseEntity<Object> checkAccount(@RequestBody @Validated CheckAccountRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Get info of receiver (bank) contain fee","0","0" ));
        return new ResponseEntity<>(iTransferToBanks.checkAccount(request), HttpStatus.OK);
    }

    @PostMapping("/check-account/no_fee")
    public ResponseEntity<Object> checkOnlyBankAccountNo(@RequestBody @Validated CheckOnlyBankAccountNoRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Get info of receiver (bank)","0","0" ));
        return new ResponseEntity<>(iTransferToBanks.checkOnlyBankAccountNo(request), HttpStatus.OK);
    }

}
