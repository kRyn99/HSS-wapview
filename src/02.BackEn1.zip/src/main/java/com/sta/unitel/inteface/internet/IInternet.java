/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to define some abstract methods of Internet businesses.
 */
package com.sta.unitel.inteface.internet;

import com.sta.unitel.inteface.commons.dto.NativeRes;

public interface IInternet {
    NativeRes confirmInternet(InternetRequest request);
    NativeRes checkInfoInternet(CheckInfoInternetRequest request);
}
