package com.sta.unitel.inteface.electric_bill;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ConfirmElectricTransRequest {
    private String account;
    private String otp;
    private String pin;
    private String partnerCode;
    private String phoneNumber;
    private String branchCode;
    private boolean save;
    private Long amount;
    private String lang;
}
