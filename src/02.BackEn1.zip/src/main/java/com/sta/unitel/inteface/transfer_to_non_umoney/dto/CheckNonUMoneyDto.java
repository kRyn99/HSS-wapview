/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "check receiver info (non-umoney)" API.
 */
package com.sta.unitel.inteface.transfer_to_non_umoney.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CheckNonUMoneyDto {
    private String responseCode;
    private String responseDescription;
    private String receiverPhone;
    private String senderPhone;
    private String senderName;
    private String fee;
    private String discount;
    private String bonus;
}
