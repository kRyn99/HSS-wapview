/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to control water bill businesses.
 */
package com.sta.unitel.controller;

import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.inteface.water_bill.IWaterBill;
import com.sta.unitel.inteface.water_bill.request.CheckWaterBillRequest;
import com.sta.unitel.inteface.water_bill.request.ConfirmWaterBillRequest;
import com.sta.unitel.inteface.water_bill.request.WaterBillProvidersRequest;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@RequestMapping("/api/v1/water-bill")
@CrossOrigin("*")
public class WaterBillController {
    private static final String U_MONEY = "U-Money";
    private final IWaterBill iWaterBill;
    private final ITransactions iTransactions;

    public WaterBillController(IWaterBill iWaterBill, ITransactions iTransactions) {
        this.iWaterBill = iWaterBill;
        this.iTransactions = iTransactions;
    }

    @PostMapping("/check")
    public ResponseEntity<Object> checkWaterBill(@RequestBody @Validated CheckWaterBillRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Check customer info on water bill","0","0" ));
        return new ResponseEntity<>(iWaterBill.checkWaterBill(request), HttpStatus.OK);
    }

    @PostMapping("/confirm")
    public ResponseEntity<Object> confirmWaterBill(@RequestBody @Validated ConfirmWaterBillRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Confirm water bill transaction","0","0" ));
        return new ResponseEntity<>(iWaterBill.confirmWaterBill(request), HttpStatus.OK);
    }

    @PostMapping("/listRecent")
    public ResponseEntity<Object> getListWaterBillTransRecent(@RequestBody @Validated WaterBillRecentRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Get list water bill transaction recent","0","0" ));
        return new ResponseEntity<>(iWaterBill.getListWaterBillTransRecent(request, request.getLimit(),
                request.getOffset(), request.getPhoneNumber(), request.getRoleId(), request.getToken()), HttpStatus.OK);
    }

    @GetMapping("/listProviders")
    public ResponseEntity<Object> getListWaterBillProviders(@Validated WaterBillProvidersRequest request)
    {
        iTransactions.save(new Transaction(U_MONEY,"Get list water bill providers","0","0" ));
        return new ResponseEntity<>(iWaterBill.getListWaterBillProviders(request), HttpStatus.OK);
    }
}
