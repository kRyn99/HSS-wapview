/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define some fields of request for "confirm internet-payment" API.
 */
package com.sta.unitel.inteface.internet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class InternetRequest {
    private String account;
    private Long amount;
    private String otp;
    private String phoneNumber;
    private String pin;
    private String type;
    private String lang;
}
