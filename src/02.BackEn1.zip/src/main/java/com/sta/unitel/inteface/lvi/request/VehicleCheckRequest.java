package com.sta.unitel.inteface.lvi.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class VehicleCheckRequest {
    private String certificate;
    @JsonProperty("new")
    private boolean news;
    private String packageCode;
    private String phoneNumber;
    private String vehicleCode;
    private String lang;
}
