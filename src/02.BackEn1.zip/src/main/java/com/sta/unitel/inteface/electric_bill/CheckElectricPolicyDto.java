package com.sta.unitel.inteface.electric_bill;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CheckElectricPolicyDto {
    private String responseCode;
    private String responseDescription;
    private String balance;
    private String transactionDateTime;
    private boolean requireOtp;
    private String accountName;
    private String discount;
    private String fee;
    private String bonus;
}
