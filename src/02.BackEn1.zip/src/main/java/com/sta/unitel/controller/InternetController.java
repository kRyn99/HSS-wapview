/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to control internet businesses.
 */
package com.sta.unitel.controller;

import com.sta.unitel.inteface.internet.CheckInfoInternetRequest;
import com.sta.unitel.inteface.internet.IInternet;
import com.sta.unitel.inteface.internet.InternetRequest;
import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@RequestMapping("/api/v1/internet")
@CrossOrigin("*")
public class InternetController {
    private final IInternet iInternet;
    private final ITransactions iTransactions;

    public InternetController(IInternet iInternet, ITransactions iTransactions) {
        this.iInternet = iInternet;
        this.iTransactions = iTransactions;
    }

    @PostMapping("/confirm-internet")
    public ResponseEntity<Object> confirmInternet(@RequestBody @Validated InternetRequest request)
    {
        iTransactions.save(new Transaction("U-Money","Confirm internet transaction","0","0" ));
        return new ResponseEntity<>(iInternet.confirmInternet(request), HttpStatus.OK);
    }
    @PostMapping("/check-internet")
    public ResponseEntity<Object> confirmInternet(@RequestBody @Validated CheckInfoInternetRequest request)
    {
        iTransactions.save(new Transaction("U-Money","Check internet account info","0","0" ));
        return new ResponseEntity<>(iInternet.checkInfoInternet(request), HttpStatus.OK);
    }
}
