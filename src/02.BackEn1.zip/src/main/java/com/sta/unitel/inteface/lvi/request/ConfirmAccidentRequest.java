package com.sta.unitel.inteface.lvi.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ConfirmAccidentRequest {
    private Long amount;
    private String otp;
    private String pin;
    private String phoneNumber;
    private String packageCode;
    private String deliveryCode;
    private String roleId;
    private String fullName;
    private String dateOfBirth;
    private Integer paperType;
    private String paperNumber;
    private String lang;
}
