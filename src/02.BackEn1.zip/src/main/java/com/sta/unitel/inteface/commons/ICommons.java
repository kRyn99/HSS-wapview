/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to define some abstract common methods.
 */
package com.sta.unitel.inteface.commons;

import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.commons.request.CheckAccountEWalletRequest;
import com.sta.unitel.inteface.commons.request.OtpRequest;
import com.sta.unitel.inteface.commons.request.TransactionDetailRequest;
import com.sta.unitel.inteface.commons.request.TransactionRecentRequest;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;


public interface ICommons {


    NativeRes getOtp(OtpRequest request);

    NativeRes getListTransactionRecent(TransactionRecentRequest request, String limit, String offset,
                                       String phoneNumber, String roleId, String token);

    NativeRes getTransDetail(TransactionDetailRequest request);

    NativeRes getListRecentBank(WaterBillRecentRequest request, String limit, String offset,
                                String phoneNumber, String roleId, String token);

    NativeRes getListRecentUMoney(WaterBillRecentRequest request, String limit, String offset,
                                  String phoneNumber, String roleId, String token);

    NativeRes getListRecentNonUMoney(WaterBillRecentRequest request, String limit, String offset,
                                     String phoneNumber, String roleId, String token);

    NativeRes getApiBase(HttpMethod method, String url, HttpEntity<Object> httpEntity);

    NativeRes checkAccountEWallet(CheckAccountEWalletRequest request);
}
