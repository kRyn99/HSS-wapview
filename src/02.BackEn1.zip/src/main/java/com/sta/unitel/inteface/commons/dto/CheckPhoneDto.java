package com.sta.unitel.inteface.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CheckPhoneDto {
    private Object fieldMap;
    private String responseDescription;
    private String processCode;
    private String description;
    private String error;
    private String responseCode;
    private String message_account;
    private Integer status;
}
