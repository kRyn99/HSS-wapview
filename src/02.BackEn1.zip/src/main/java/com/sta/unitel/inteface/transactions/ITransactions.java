/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to declare an abstract method to save the logs in database when API called.
 */
package com.sta.unitel.inteface.transactions;

import com.sta.unitel.model.Transaction;

@FunctionalInterface
public interface ITransactions {
    Transaction save(Transaction transaction);
}
