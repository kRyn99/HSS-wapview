/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to implement the methods that defined in ITransaction interface.
 */
package com.sta.unitel.service;

import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.model.Transaction;
import com.sta.unitel.repository.TransactionsRepository;
import org.springframework.stereotype.Service;

@Service
public class TransactionsService implements ITransactions
{
    private final TransactionsRepository transactionsRepository;

    public TransactionsService(TransactionsRepository transactionsRepository)
    {
        this.transactionsRepository = transactionsRepository;
    }
    public Transaction save(Transaction transaction)
    {
        return transactionsRepository.save(transaction);
    }
}
