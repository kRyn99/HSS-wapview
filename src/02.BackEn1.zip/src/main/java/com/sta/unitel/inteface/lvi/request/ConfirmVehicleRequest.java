package com.sta.unitel.inteface.lvi.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ConfirmVehicleRequest {
    @JsonProperty("new")
    private boolean news;
    private String phoneNumber;
    private String pin;
    private String otp;
    private String vehicleCode;
    private String packageCode;
    private String deliveryCode;
    private String certificate;
    private String fileName;
    private String roleId;
    private String lang;
}
