/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to declare some abstract methods of transfer to u-money businesses.
 */
package com.sta.unitel.inteface.transfer_to_umoney;

import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.transfer_to_umoney.request.CheckAccountUMoneyRequest;
import com.sta.unitel.inteface.transfer_to_umoney.request.ConfirmTransferToUMoneyRequest;

public interface ITransferToUMoney {
    NativeRes checkAccountUMoneyInfo(CheckAccountUMoneyRequest request);
    NativeRes checkAccountMocha(CheckAccountUMoneyRequest request);
    NativeRes confirmTrans(ConfirmTransferToUMoneyRequest request);
}

