package com.sta.unitel.inteface.electric_bill;

import com.sta.unitel.inteface.buy_data.dto.ConfirmBuyDataDto;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.commons.dto.NativeRes1;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;

import java.util.List;

public interface IElectric {
    NativeRes getListBranches(ListBranchesRequest request);

    //    NativeRes checkInfoElectric(CheckInfoElectricRequest request);
    NativeRes1<CheckInfoElectricDto> checkInfoElectric(CheckInfoElectricRequest request);

    //    NativeRes checkPolicyElectric(CheckPolicyElectricRequest request);
    NativeRes1<CheckElectricPolicyDto> checkPolicyElectric(CheckPolicyElectricRequest request);

    //    NativeRes listRecentElectric(WaterBillRecentRequest request, String limit,
//                                 String offset, String phoneNumber, String roleId, String token);
    NativeRes1<List<ListRecentElectricDto>> listRecentElectric(WaterBillRecentRequest request, String limit,
                                                               String offset, String phoneNumber,
                                                               String roleId, String token);

    //    NativeRes confirmElectricTrans(ConfirmElectricTransRequest request);
    NativeRes1<ConfirmBuyDataDto> confirmElectricTrans(ConfirmElectricTransRequest request);
}
