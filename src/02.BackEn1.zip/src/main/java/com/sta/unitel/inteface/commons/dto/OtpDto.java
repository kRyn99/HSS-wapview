/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to define DTO for "get Otp" API.
 */
package com.sta.unitel.inteface.commons.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OtpDto {
    private String responseCode;
    private String responseDescription;
    private String phoneNumber;
    private String transactionDateTime;
    private boolean requireOtp;
}
