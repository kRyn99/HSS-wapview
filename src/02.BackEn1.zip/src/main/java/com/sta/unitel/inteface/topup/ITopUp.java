/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This interface is to define some abstract methods of top-up businesses.
 */
package com.sta.unitel.inteface.topup;

import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.topup.request.CheckInfoTopUpRequest;
import com.sta.unitel.inteface.topup.request.ConfirmTransactionTopUpRequest;
import com.sta.unitel.inteface.topup.request.TopUpRecentRequest;

public interface ITopUp {
    NativeRes checkInfoTopUp(CheckInfoTopUpRequest request);
    NativeRes confirmTransactionTopUp(ConfirmTransactionTopUpRequest request);
    NativeRes getListTopUpRecent(TopUpRecentRequest request, String limit, String offset,
                                 String phoneNumber, String roleId, String token);
}
