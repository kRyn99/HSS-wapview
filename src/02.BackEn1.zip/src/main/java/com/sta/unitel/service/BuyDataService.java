/*
 * Unitel WebView, Mobile web applications system.
 * Copyright (C) 2021 Unitel, Star Telecom Co.Ltd.
 * mailto: unitellao AT unitel DOT com DOT la
 *
 * This class is to implement the methods that defined in IBuyData interface.
 */
package com.sta.unitel.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sta.unitel.inteface.buy_data.IBuyData;
import com.sta.unitel.inteface.buy_data.dto.ConfirmBuyDataDto;
import com.sta.unitel.inteface.buy_data.dto.PackageTypeDto;
import com.sta.unitel.inteface.buy_data.request.BuyDataDetailRequest;
import com.sta.unitel.inteface.buy_data.request.BuyDataListRequest;
import com.sta.unitel.inteface.buy_data.request.ConfirmBuyDataRequest;
import com.sta.unitel.inteface.commons.ICommons;
import com.sta.unitel.inteface.commons.dto.NativeRes;
import com.sta.unitel.inteface.commons.dto.NativeRes1;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;

@Service
public class BuyDataService implements IBuyData {
    @Value("${prefix-url-service}")
    private String prefix_service_url;

    private final ObjectMapper mapper;
    private ICommons iCommons;

    public BuyDataService(ObjectMapper mapper, ICommons iCommons) {
        this.mapper = mapper;
        this.iCommons = iCommons;
    }

    @Override
    public NativeRes getListDataPackages(BuyDataListRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/partner/v2.0/data/packages?phoneNumber=%s&token=%s";
        String url = String.format(uri, request.getPhoneNumber(), request.getToken());
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        if (request.getToken() == null || request.getToken().equals("")) {
//            Gson g = new Gson();
//            try {
//                ClassLoader classLoader = getClass().getClassLoader();
//                String fileName = "public/list_packages_data.json";
//                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
//                String content = new String(Files.readAllBytes(file.toPath()));
//                return g.fromJson(content, NativeRes.class);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
            PackageTypeDto packageTypeDto = new PackageTypeDto();

            return new NativeRes(200, "Get list bank successful", packageTypeDto);
      }
        httpHeaders.set("Accept-Language", request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        return iCommons.getApiBase(HttpMethod.GET, url, httpEntity);
    }

    @Override
    public NativeRes getPackageDetail(BuyDataDetailRequest request) {
        final String uri = prefix_service_url + "mobileservice/api/partner/v2.0/data/package/" +
                "{code}/detail?phoneNumber=%s&token=%s&type=%s";
        CloseableHttpClient httpClient = HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier()).build();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);
        RestTemplate restTemplate = new RestTemplate(requestFactory);
        Map<String, String> param = new HashMap<>();
        param.put("code", request.getCode());
        String url = String.format(uri, request.getPhoneNumber(), request.getToken(), request.getType());
        HttpHeaders httpHeaders = new HttpHeaders();
        if (request.getLang() == null) {
            request.setLang("en");
        }
        if (request.getToken() == null || request.getToken().equals("")) {
            Gson g = new Gson();
            String fileName = "";
            try {
                ClassLoader classLoader = getClass().getClassLoader();
                switch (request.getCode()) {
                    case "4G_50":
                        fileName = "public/buy_data/ca_4g_50.json";
                        break;
                    case "4G_120":
                        fileName = "public/buy_data/ca_4g_120.json";
                        break;
                    case "4G_100":
                        fileName = "public/buy_data/ca_4g_100.json";
                        break;
                    case "4G_MI1":
                        fileName = "public/buy_data/ca_4g_mi1.json";
                        break;
                    case "4G_MI10":
                        fileName = "public/buy_data/ca_4g_mi10.json";
                        break;
                    case "4G_MI2":
                        fileName = "public/buy_data/ca_4g_mi12.json";
                        break;
                    case "4G_MI5":
                        fileName = "public/buy_data/ca_4g_mi5.json";
                        break;
                    case "YT3":
                        fileName = "public/buy_data/ca_yt3.json";
                        break;
                    case "AD20":
                        fileName = "public/buy_data/ca_ad20.json";
                        break;
                    case "S15":
                        fileName = "public/buy_data/sp_s15.json";
                        break;
                    case "MI3":
                        fileName = "public/buy_data/sp_mi3.json";
                        break;
                    case "MI79":
                        fileName = "public/buy_data/sp_mi79.json";
                        break;
                }
                File file = new File(Objects.requireNonNull(classLoader.getResource(fileName)).getFile());
                String content = new String(Files.readAllBytes(file.toPath()));
                return g.fromJson(content, NativeRes.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        httpHeaders.set("Accept-Language", request.getLang());
        HttpEntity<Object> httpEntity = new HttpEntity<>(request, httpHeaders);
        String error;
        try {
            return restTemplate.exchange(url, HttpMethod.GET, httpEntity, NativeRes.class, param).getBody();
        } catch (HttpStatusCodeException exception) {
            error = exception.getResponseBodyAsString();
            try {
                return mapper.readValue(error, NativeRes.class);
            } catch (JsonProcessingException e) {
                throw new IllegalArgumentException(e);
            }
        }
    }

    @Override
    public NativeRes1<ConfirmBuyDataDto> confirmBuyData(ConfirmBuyDataRequest request) {
        if (request.getOtp().equals("222222")) {
            return new NativeRes1<>(200, "Transaction successfully", new ConfirmBuyDataDto("00000",
                    "Transaction successfully.",
                    "210106000170760",
                    "15:28 06/01/2021",
                    false));
        } else {
            return new NativeRes1<>(403, "The OTP is invalid", new ConfirmBuyDataDto("10003",
                    "The OTP is invalid.",
                    "210302000188760",
                    "13:38 02/03/2021",
                    false));
        }
    }
}
