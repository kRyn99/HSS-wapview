package com.sta.unitel.controller;

import com.sta.unitel.inteface.electric_bill.CheckInfoElectricRequest;
import com.sta.unitel.inteface.electric_bill.CheckPolicyElectricRequest;
import com.sta.unitel.inteface.electric_bill.IElectric;
import com.sta.unitel.inteface.electric_bill.ListBranchesRequest;
import com.sta.unitel.inteface.electric_bill.ConfirmElectricTransRequest;
import com.sta.unitel.inteface.transactions.ITransactions;
import com.sta.unitel.inteface.water_bill.request.WaterBillRecentRequest;
import com.sta.unitel.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@RequestMapping("/api/v1/electric-bill")
@CrossOrigin("*")
public class ElectricBillController {
    private static final String U_MONEY = "U-Money";
    private final IElectric iElectric;
    private final ITransactions iTransactions;

    public ElectricBillController(IElectric iElectric, ITransactions iTransactions) {
        this.iElectric = iElectric;
        this.iTransactions = iTransactions;
    }

    @GetMapping("/listBranches")
    public ResponseEntity<Object> getListBranches(@Validated ListBranchesRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"Get list electricity branches","0","0" ));
        return new ResponseEntity<>(iElectric.getListBranches(request), HttpStatus.OK);
    }
    @PostMapping("/check-electric-info")
    public ResponseEntity<Object> checkInfoElectric(@RequestBody @Validated CheckInfoElectricRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"Check electricity customer info","0","0" ));
        return new ResponseEntity<>(iElectric.checkInfoElectric(request), HttpStatus.OK);
    }
    @PostMapping("/check-electric-policy")
    public ResponseEntity<Object> checkPolicyElectric(@RequestBody @Validated CheckPolicyElectricRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"Check electricity customer policy","0","0" ));
        return new ResponseEntity<>(iElectric.checkPolicyElectric(request), HttpStatus.OK);
    }
    @PostMapping("/electric-recent")
    public ResponseEntity<Object> listRecentElectric(@RequestBody @Validated WaterBillRecentRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"get list electric recent","0","0" ));
        return new ResponseEntity<>(iElectric.listRecentElectric(request, request.getLimit(),
                request.getOffset(), request.getPhoneNumber(), request.getRoleId(), request.getToken()), HttpStatus.OK);
    }
    @PostMapping("/confirm-electric-transaction")
    public ResponseEntity<Object> confirmElectricTrans(@RequestBody @Validated ConfirmElectricTransRequest request) {
        iTransactions.save(new Transaction(U_MONEY,"Check electricity customer info","0","0" ));
        return new ResponseEntity<>(iElectric.confirmElectricTrans(request), HttpStatus.OK);
    }
}
